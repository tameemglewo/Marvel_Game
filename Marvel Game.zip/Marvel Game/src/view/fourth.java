package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import engine.Game;
import engine.Player;

public class fourth extends JFrame implements ActionListener {
	Player p1;
	Player p2;
	JPanel panel1;
	JPanel panel2;
	JButton[] x;
	JButton[] y;
	JLabel label1;
	JLabel label2;
	

	public fourth(Player p1, Player p2) {
		this.p1 = p1;
		this.p2 = p2;

		x = new JButton[3];
		for (int i = 0; i < 3; i++) {
			x[i] = new JButton(p1.getTeam().get(i).getName());
			x[i].addActionListener(this);
		}
		x[0].setSize(240, 240);
		x[0].setLocation(240, 100);
		x[1].setSize(240, 240);
		x[1].setLocation(580, 100);
		x[2].setSize(240, 240);
		x[2].setLocation(920, 100);
		
		label1=new JLabel(p1.getName()+" choose your leader");
		label1.setSize(500, 20);
		label1.setLocation(540, 30);
		label1.setFont(new Font("Arial",Font.BOLD,22));
		
		panel1 = new JPanel();
		panel1.setSize(1400, 900);
		panel1.setLayout(null);
		panel1.setBackground(Color.BLUE);
		for (int i = 0; i < 3; i++) {
			panel1.add(x[i]);
		}
		panel1.add(label1);

		y = new JButton[3];
		for (int i = 0; i < 3; i++) {
			y[i] = new JButton(p2.getTeam().get(i).getName());
			y[i].addActionListener(this);
		}
		y[0].setSize(240, 240);
		y[0].setLocation(240, 100);
		y[1].setSize(240, 240);
		y[1].setLocation(580, 100);
		y[2].setSize(240, 240);
		y[2].setLocation(920, 100);
		
		label2=new JLabel(p2.getName()+" choose your leader");
		label2.setSize(500, 20);
		label2.setLocation(540, 30);
		label2.setFont(new Font("Arial",Font.BOLD,22));
		
		panel2 = new JPanel();
		panel2.setSize(1400, 900);
		panel2.setLayout(null);
		panel2.setBackground(Color.RED);
		for (int i = 0; i < 3; i++) {
			panel2.add(y[i]);
		}
		panel2.add(label2);

		this.setSize(1400,900);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(new GridLayout(2, 0));
		this.setTitle("Marvel game");
		this.setVisible(true);
		this.add(panel1);
		this.add(panel2);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		for (int i = 0; i < 3; i++) {
			if (e.getSource() == x[i]) {
				if (p1.getLeader() == null) {
					p1.setLeader(p1.getTeam().get(i));
					x[i].setEnabled(false);
				}
			} else if (e.getSource() == y[i]) {
				if (p2.getLeader() == null) {
					p2.setLeader(p2.getTeam().get(i));
					y[i].setEnabled(false);
				}
			}
			
		}
		if (p1.getLeader() != null && p2.getLeader() != null) {
			fifth window = new fifth(p1, p2);
			this.dispose();
		}

	}

}

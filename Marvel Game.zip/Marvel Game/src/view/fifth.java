package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Label;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Timer;

import javax.swing.BorderFactory;
import javax.swing.ComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

import engine.Game;
import engine.Player;
import engine.PriorityQueue;
import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;
import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.effects.Effect;
import model.world.Champion;
import model.world.Cover;
import model.world.Direction;

public class fifth extends JFrame implements KeyListener, ActionListener, MouseListener {
	Player p1;
	Player p2;
	JPanel bpanel;
	JLabel[][] x;
	ImageIcon coverimage;
	Game game;
	JPanel upPanel;
	JPanel downPanel;
	JPanel downPanel2;
	JPanel rightPanel;
	JPanel leftPanel;
	JButton[] abilitiesb;
	JLabel abilitiesN;
	JButton leaderAbility;
	int castDirectional;
	int castSingleTarget;
	Ability a;
	JPanel abilitiesPanel;
	JLabel championInfo;
	String Aeffects;
	String leader;
	JLabel p1label;
	JLabel p2label;
	JButton[] p1champions;
	JButton[] p2champions;
	ArrayList<Champion> turn;
	JButton[] championsTurn;
	String fua;
	String sua;
	JLabel ffua;
	JLabel ssua;

	public fifth(Player p1, Player p2) {
		this.p1 = p1;
		this.p2 = p2;
		coverimage = new ImageIcon("shield.jpeg");
		game = new Game(p1, p2);
		castDirectional = 0;
		abilitiesPanel = new JPanel();

		abilitiesb = new JButton[game.getCurrentChampion().getAbilities().size()];
		for (int i = 0; i < game.getCurrentChampion().getAbilities().size(); i++) {
			abilitiesb[i] = new JButton();
			abilitiesb[i].setFocusable(false);
			abilitiesb[i].setText(game.getCurrentChampion().getAbilities().get(i).getName() + "("
					+ game.getCurrentChampion().getAbilities().get(i).getCastArea() + ")");
			abilitiesb[i].setSize(250, 50);
			abilitiesb[i].setLocation(10, 40 + i * 60);
			abilitiesb[i].addActionListener(this);
			abilitiesb[i].addMouseListener(this);

		}
		abilitiesN = new JLabel();
		abilitiesN.setText(game.getCurrentChampion().getName() + " available abilities");
		abilitiesN.setSize(250, 30);
		abilitiesN.setLocation(10, 10);
		abilitiesN.setFont(new Font("Arial", Font.BOLD, 16));

		leaderAbility = new JButton("use leader ability");
		leaderAbility.setSize(250, 50);
		leaderAbility.setLocation(10, 400);
		leaderAbility.setFocusable(false);
		leaderAbility.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == leaderAbility) {
					try {
						game.useLeaderAbility();
						updateBoard();
					} catch (LeaderNotCurrentException e1) {
						final JPanel p1 = new JPanel();
						p1.add(new JLabel("The current champion is not a leader"));
						downPanel.add(p1);
						revalidate();
						repaint();
						final int[] count = new int[] { 0 };
						javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
							@Override
							public void actionPerformed(ActionEvent e) {
								if (++count[0] == 20) {
									((javax.swing.Timer) e.getSource()).stop();
									downPanel.remove(p1);
									revalidate();
									repaint();
									requestFocusInWindow();
								}

							}
						});
						t.start();
					} catch (LeaderAbilityAlreadyUsedException e1) {
						final JPanel p1 = new JPanel();
						p1.add(new JLabel("This leader already used his ability"));
						downPanel.add(p1);
						revalidate();
						repaint();
						final int[] count = new int[] { 0 };
						javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
							@Override
							public void actionPerformed(ActionEvent e) {
								if (++count[0] == 20) {
									((javax.swing.Timer) e.getSource()).stop();
									downPanel.remove(p1);
									revalidate();
									repaint();
									requestFocusInWindow();
								}

							}
						});
						t.start();

					}
				}

			}
		});
		fua = "ON";
		ffua = new JLabel();
		ffua.setText(p1.getLeader().getName() + ":" + fua);
		ffua.setSize(400, 18);
		ffua.setLocation(10, 460);
		ffua.setFont(new Font("Arial", Font.BOLD, 18));

		sua = "ON";
		ssua = new JLabel();
		ssua.setText(p2.getLeader().getName() + ":" + sua);
		ssua.setSize(400, 18);
		ssua.setLocation(10, 480);
		ssua.setFont(new Font("Arial", Font.BOLD, 18));

		p1label = new JLabel();
		p1label.setText(p1.getName() + "'s team");
		p1label.setLocation(60, 20);
		p1label.setSize(330, 30);
		p1label.setFont(new Font("Arial", Font.BOLD, 24));

		p2label = new JLabel();
		p2label.setText(p2.getName() + "'s team");
		p2label.setLocation(1120, 20);
		p2label.setSize(330, 30);
		p2label.setFont(new Font("Arial", Font.BOLD, 24));

		p1champions = new JButton[p1.getTeam().size()];
		for (int i = 0; i < p1.getTeam().size(); i++) {
			p1champions[i] = new JButton(p1.getTeam().get(i).getName());
			p1champions[i].setSize(100, 80);
			p1champions[i].setLocation(40 + i * 100, 60);
			p1champions[i].setFocusable(false);
			p1champions[i].addActionListener(this);
		}
		p2champions = new JButton[p2.getTeam().size()];
		for (int i = 0; i < p2.getTeam().size(); i++) {
			p2champions[i] = new JButton(p2.getTeam().get(i).getName());
			p2champions[i].setSize(100, 80);
			p2champions[i].setLocation(1110 + i * 100, 60);
			p2champions[i].setFocusable(false);
			p2champions[i].addActionListener(this);
		}

		turn = new ArrayList<>();
		PriorityQueue temp = new PriorityQueue(game.getTurnOrder().size());
		while (!game.getTurnOrder().isEmpty()) {
			Champion c = (Champion) game.getTurnOrder().remove();
			temp.insert(c);
			turn.add(c);
		}
		while (!temp.isEmpty()) {
			game.getTurnOrder().insert(temp.remove());
		}
		championsTurn = new JButton[turn.size()];
		for (int i = 0; i < turn.size(); i++) {
			championsTurn[i] = new JButton(turn.get(i).getName());
			championsTurn[i].setLocation(475 + i * 85, 5);
			championsTurn[i].setSize(75, 75);
			championsTurn[i].setFocusable(false);
		}

		// panels
		upPanel = new JPanel();
		upPanel.setBackground(Color.gray);
		upPanel.setSize(1500, 150);
		upPanel.setLocation(0, 0);
		upPanel.setLayout(null);
		upPanel.add(p1label);
		upPanel.add(p2label);
		for (int i = 0; i < p1.getTeam().size(); i++) {
			upPanel.add(p1champions[i]);
		}
		for (int i = 0; i < p2.getTeam().size(); i++) {
			upPanel.add(p2champions[i]);
		}

		downPanel = new JPanel();
		downPanel.setBackground(Color.gray);
		downPanel.setSize(1500, 65);
		downPanel.setLocation(0, 650);

		downPanel2 = new JPanel();
		downPanel2.setBackground(Color.gray);
		downPanel2.setLayout(null);
		downPanel2.setSize(1500, 85);
		downPanel2.setLocation(0, 715);
		for (int i = 0; i < championsTurn.length; i++) {
			// System.out.println(championsTurn.length);
			downPanel2.add(championsTurn[i]);
		}

		rightPanel = new JPanel();
		rightPanel.setBackground(Color.gray);
		rightPanel.setLayout(null);
		rightPanel.setSize(270, 500);
		rightPanel.setLocation(1170, 150);
		rightPanel.add(abilitiesN);
		for (int i = 0; i < abilitiesb.length; i++) {
			rightPanel.add(abilitiesb[i]);
		}
		rightPanel.add(leaderAbility);
		rightPanel.add(ffua);
		rightPanel.add(ssua);

		leftPanel = new JPanel();
		leftPanel.setBackground(Color.gray);
		leftPanel.setSize(270, 500);
		leftPanel.setLocation(0, 150);
		championInfo = new JLabel();
		championInfo.setFont(new Font("Arial", Font.BOLD, 16));
		leftPanel.add(championInfo);
		Aeffects = "";
		for (int i = 0; i < game.getCurrentChampion().getAppliedEffects().size(); i++) {
			Aeffects += " " + game.getCurrentChampion().getAppliedEffects().get(i).getName() + "("
					+ game.getCurrentChampion().getAppliedEffects().get(i).getDuration() + ")";
		}
		leader = "no";
		if (game.getCurrentChampion() == p1.getLeader() || game.getCurrentChampion() == p2.getLeader()) {
			leader = "yes";
		}

		championInfo.setText("<html>Turn on:" + game.getCurrentChampion().getName() + "<br><br>Leader:" + leader
				+ "<br><br>Type:" + game.getCurrentChampion().getClass().getSimpleName() + "<br><br>Max health:"
				+ game.getCurrentChampion().getMaxHP() + "<br><br>Current healt:"
				+ game.getCurrentChampion().getCurrentHP() + "<br><br>Mana:" + game.getCurrentChampion().getMana()
				+ "<br><br>Max actions points per turn:" + game.getCurrentChampion().getMaxActionPointsPerTurn()
				+ "<br><br>Current actions point:" + game.getCurrentChampion().getCurrentActionPoints()
				+ "<br><br>Attack range:" + game.getCurrentChampion().getAttackRange() + "<br><br>Attack damage:"
				+ game.getCurrentChampion().getAttackDamage() + "<br><br>Speed:" + game.getCurrentChampion().getSpeed()
				+ "<br><br>Condition:" + game.getCurrentChampion().getCondition() + "<br><br>Applied effects:"
				+ Aeffects);

		// board
		bpanel = new JPanel();
		bpanel.setLayout(new GridLayout(5, 5, 10, 10));
		bpanel.setBackground(Color.black);
		bpanel.setSize(900, 500);
		bpanel.addKeyListener(this);
		bpanel.setFocusable(true);
		bpanel.requestFocusInWindow();
		bpanel.setLocation(270, 150);
		x = new JLabel[5][5];
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				x[i][j] = new JLabel();
				x[i][j].addMouseListener(this);
				x[i][j].setBorder(BorderFactory.createEtchedBorder());
				x[i][j].setBackground(Color.white);
				x[i][j].setForeground(Color.white);
				bpanel.add(x[i][j]);
			}

		}
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				Object[][] y = game.getBoard();
				if (y[i][j] != null) {
					if (y[i][j] instanceof Champion) {
						Champion c = (Champion) y[i][j];
						x[i][j].setText("<html>" + c.getName() + "<br>HP:" + c.getCurrentHP());
						x[i][j].setHorizontalAlignment(JLabel.CENTER);
						if (game.memberIn(c) == p1) {
							x[i][j].setBackground(Color.blue);
							x[i][j].setForeground(Color.blue);
						} else {
							x[i][j].setBackground(Color.red);
							x[i][j].setForeground(Color.red);
						}

					} else {
						Cover cover = (Cover) y[i][j];
						x[i][j].setText(cover.getCurrentHP() + "");
						x[i][j].setHorizontalAlignment(JLabel.CENTER);
					}
				}

			}
		}

		this.setSize(1500,900);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(null);
		this.setTitle("Marvel game");
		this.addKeyListener(this);
		this.setVisible(true);
		this.setBackground(Color.DARK_GRAY);
		this.add(bpanel);
		this.add(upPanel);
		this.add(downPanel);
		this.add(rightPanel);
		this.add(leftPanel);
		this.add(downPanel2);

	}

	public void prepareAilities(Champion c) {
		for (int i = 0; i < abilitiesb.length; i++) {
			rightPanel.remove(abilitiesb[i]);
		}
		abilitiesb = new JButton[c.getAbilities().size()];
		for (int i = 0; i < c.getAbilities().size(); i++) {
			abilitiesb[i] = new JButton();
			abilitiesb[i]
					.setText(c.getAbilities().get(i).getName() + "(" + c.getAbilities().get(i).getCastArea() + ")");
			abilitiesb[i].setFocusable(false);
			abilitiesb[i].setSize(250, 50);
			abilitiesb[i].setLocation(10, 40 + i * 60);
			abilitiesb[i].addActionListener(this);
			abilitiesb[i].addMouseListener(this);
		}
		abilitiesN.setText(c.getName() + " available abilities");
		for (int i = 0; i < abilitiesb.length; i++) {
			rightPanel.add(abilitiesb[i]);
		}
		rightPanel.revalidate();
		rightPanel.repaint();

	}

	public void updateBoard() {
		if (game.checkGameOver() == p1) {
			winner window = new winner(p1);
			this.dispose();
		} else if (game.checkGameOver() == p2) {
			winner window = new winner(p2);
			this.dispose();
		} else

		if (game.isFirstLeaderAbilityUsed()) {
			rightPanel.remove(ffua);
			fua = "OFF";
			ffua.setText(p1.getLeader().getName() + ":" + fua);
			rightPanel.add(ffua);

		}
		if (game.isSecondLeaderAbilityUsed()) {
			rightPanel.remove(ssua);
			sua = "OFF";
			ssua.setText(p2.getLeader().getName() + ":" + sua);
			rightPanel.add(ssua);

		}
		Aeffects = "";
		for (int i = 0; i < game.getCurrentChampion().getAppliedEffects().size(); i++) {
			Aeffects += " " + game.getCurrentChampion().getAppliedEffects().get(i).getName() + "("
					+ game.getCurrentChampion().getAppliedEffects().get(i).getDuration() + ")";
		}
		championInfo.removeAll();
		leftPanel.remove(championInfo);
		leader = "no";
		if (game.getCurrentChampion() == p1.getLeader() || game.getCurrentChampion() == p2.getLeader()) {
			leader = "yes";
		}

		championInfo.setText("<html>Turn on:" + game.getCurrentChampion().getName() + "<br><br>Leader:" + leader
				+ "<br><br>Type:" + game.getCurrentChampion().getClass().getSimpleName() + "<br><br>Max health:"
				+ game.getCurrentChampion().getMaxHP() + "<br><br>Current healt:"
				+ game.getCurrentChampion().getCurrentHP() + "<br><br>Mana:" + game.getCurrentChampion().getMana()
				+ "<br><br>Max actions points per turn:" + game.getCurrentChampion().getMaxActionPointsPerTurn()
				+ "<br><br>Current actions point:" + game.getCurrentChampion().getCurrentActionPoints()
				+ "<br><br>Attack range:" + game.getCurrentChampion().getAttackRange() + "<br><br>Attack damage:"
				+ game.getCurrentChampion().getAttackDamage() + "<br><br>Speed:" + game.getCurrentChampion().getSpeed()
				+ "<br><br>Condition:" + game.getCurrentChampion().getCondition() + "<br><br>Applied effects:"
				+ Aeffects);
		leftPanel.add(championInfo);
		revalidate();
		repaint();
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				Object[][] y = game.getBoard();
				if (y[i][j] != null) {
					if (y[i][j] instanceof Champion) {
						Champion c = (Champion) y[i][j];
						x[i][j].setText("<html>" + c.getName() + "<br>HP:" + c.getCurrentHP());
						x[i][j].setHorizontalAlignment(JLabel.CENTER);
						if (game.memberIn(c) == p1) {
							x[i][j].setBackground(Color.blue);
							x[i][j].setForeground(Color.blue);

						} else {
							x[i][j].setBackground(Color.red);
							x[i][j].setForeground(Color.red);
						}

					} else {
						Cover cover = (Cover) y[i][j];
						x[i][j].setText(cover.getCurrentHP() + "");
						x[i][j].setHorizontalAlignment(JLabel.CENTER);
						x[i][j].setBackground(Color.white);
					}
				} else {
					x[i][j].setText("");
					x[i][j].setBackground(Color.white);

				}

			}
		}
		for (int i = 0; i < p1champions.length; i++) {
			upPanel.remove(p1champions[i]);
		}
		p1champions = new JButton[p1.getTeam().size()];
		for (int i = 0; i < p1.getTeam().size(); i++) {
			p1champions[i] = new JButton(p1.getTeam().get(i).getName());
			p1champions[i].setSize(100, 80);
			p1champions[i].setLocation(40 + i * 100, 60);
			p1champions[i].setFocusable(false);
			p1champions[i].addActionListener(this);
			upPanel.add(p1champions[i]);
		}
		for (int i = 0; i < p2champions.length; i++) {
			upPanel.remove(p2champions[i]);
		}
		p2champions = new JButton[p2.getTeam().size()];
		for (int i = 0; i < p2.getTeam().size(); i++) {
			p2champions[i] = new JButton(p2.getTeam().get(i).getName());
			p2champions[i].setSize(100, 80);
			p2champions[i].setLocation(1110 + i * 100, 60);
			p2champions[i].setFocusable(false);
			p2champions[i].addActionListener(this);
			upPanel.add(p2champions[i]);
		}
		downPanel2.removeAll();
		turn = new ArrayList<>();
		PriorityQueue temp = new PriorityQueue(game.getTurnOrder().size());
		while (!game.getTurnOrder().isEmpty()) {
			Champion c = (Champion) game.getTurnOrder().remove();
			temp.insert(c);
			turn.add(c);
		}
		while (!temp.isEmpty()) {
			game.getTurnOrder().insert(temp.remove());
		}
		championsTurn = new JButton[turn.size()];
		for (int i = 0; i < turn.size(); i++) {
			championsTurn[i] = new JButton(turn.get(i).getName());
			championsTurn[i].setLocation(475 + i * 85, 5);
			championsTurn[i].setSize(75, 75);
			championsTurn[i].setFocusable(false);
		}
		for (int i = 0; i < championsTurn.length; i++) {
			downPanel2.add(championsTurn[i]);
		}
		revalidate();
		repaint();
	}

	@Override
	public void keyTyped(KeyEvent e) {
		if (e.getKeyChar() == 'q') {
			game.endTurn();
			prepareAilities(game.getCurrentChampion());
			updateBoard();
			
			if (rightPanel.contains(40, 220)) {
				rightPanel.remove(abilitiesPanel);
			}

			revalidate();
			repaint();

		}

	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (castDirectional == 0) {

			if (e.getKeyCode() == 40) {
				try {
					game.move(Direction.UP);
					updateBoard();
				} catch (NotEnoughResourcesException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} catch (UnallowedMovementException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				}

			} else if (e.getKeyCode() == 38) {
				try {
					game.move(Direction.DOWN);
					updateBoard();
				} catch (NotEnoughResourcesException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} catch (UnallowedMovementException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				}

			} else if (e.getKeyCode() == 37) {
				try {
					game.move(Direction.LEFT);
					updateBoard();
				} catch (NotEnoughResourcesException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} catch (UnallowedMovementException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				}

			} else if (e.getKeyCode() == 39) {
				try {
					game.move(Direction.RIGHT);
					updateBoard();
				} catch (NotEnoughResourcesException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} catch (UnallowedMovementException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				}

			} else if (e.getKeyCode() == 83) {

				try {
					game.attack(Direction.UP);
					updateBoard();
				} catch (NotEnoughResourcesException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} catch (ChampionDisarmedException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				}

			} else if (e.getKeyCode() == 87) {

				try {
					game.attack(Direction.DOWN);
					updateBoard();
				} catch (NotEnoughResourcesException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} catch (ChampionDisarmedException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				}

			} else if (e.getKeyCode() == 65) {

				try {
					game.attack(Direction.LEFT);
					updateBoard();
				} catch (NotEnoughResourcesException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} catch (ChampionDisarmedException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				}

			} else if (e.getKeyCode() == 68) {

				try {
					game.attack(Direction.RIGHT);
					updateBoard();
				} catch (NotEnoughResourcesException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} catch (ChampionDisarmedException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				}
			}
		} else if (castDirectional == 1) {

			if (e.getKeyCode() == 40) {
				castDirectional = 0;
				try {
					game.castAbility(a, Direction.UP);
					updateBoard();
				} catch (NotEnoughResourcesException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} catch (AbilityUseException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} catch (CloneNotSupportedException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				}
			} else if (e.getKeyCode() == 38) {
				castDirectional = 0;
				try {
					game.castAbility(a, Direction.DOWN);
					updateBoard();
				} catch (NotEnoughResourcesException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} catch (AbilityUseException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} catch (CloneNotSupportedException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				}
			} else if (e.getKeyCode() == 37) {
				castDirectional = 0;

				try {
					game.castAbility(a, Direction.LEFT);
					updateBoard();
				} catch (NotEnoughResourcesException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} catch (AbilityUseException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} catch (CloneNotSupportedException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				}
			} else if (e.getKeyCode() == 39) {
				castDirectional = 0;
				try {
					game.castAbility(a, Direction.RIGHT);
					updateBoard();
				} catch (NotEnoughResourcesException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} catch (AbilityUseException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} catch (CloneNotSupportedException e1) {
					final JPanel p1 = new JPanel();
					p1.add(new JLabel(e1.getMessage()));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				}
			}
		}

	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		for (int i = 0; i < abilitiesb.length; i++) {
			if (e.getSource() == abilitiesb[i]) {
				a = game.getCurrentChampion().getAbilities().get(i);
				if (a.getCastArea().equals(AreaOfEffect.SELFTARGET) || a.getCastArea().equals(AreaOfEffect.SURROUND)
						|| a.getCastArea().equals(AreaOfEffect.TEAMTARGET)) {
					try {
						game.castAbility(a);
						updateBoard();
					} catch (NotEnoughResourcesException e1) {
						final JPanel p1 = new JPanel();
						p1.add(new JLabel(e1.getMessage()));
						downPanel.add(p1);
						revalidate();
						repaint();
						final int[] count = new int[] { 0 };
						javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
							@Override
							public void actionPerformed(ActionEvent e) {
								if (++count[0] == 20) {
									((javax.swing.Timer) e.getSource()).stop();
									downPanel.remove(p1);
									revalidate();
									repaint();
									requestFocusInWindow();
								}

							}
						});
						t.start();

					} catch (AbilityUseException e1) {
						final JPanel p1 = new JPanel();
						p1.add(new JLabel(e1.getMessage()));
						downPanel.add(p1);
						revalidate();
						repaint();
						final int[] count = new int[] { 0 };
						javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
							@Override
							public void actionPerformed(ActionEvent e) {
								if (++count[0] == 20) {
									((javax.swing.Timer) e.getSource()).stop();
									downPanel.remove(p1);
									revalidate();
									repaint();
									requestFocusInWindow();
								}

							}
						});
						t.start();

					} catch (CloneNotSupportedException e1) {
						final JPanel p1 = new JPanel();
						p1.add(new JLabel(e1.getMessage()));
						downPanel.add(p1);
						revalidate();
						repaint();
						final int[] count = new int[] { 0 };
						javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
							@Override
							public void actionPerformed(ActionEvent e) {
								if (++count[0] == 20) {
									((javax.swing.Timer) e.getSource()).stop();
									downPanel.remove(p1);
									revalidate();
									repaint();
									requestFocusInWindow();
								}

							}
						});
						t.start();

					}
				} else if (a.getCastArea().equals(AreaOfEffect.DIRECTIONAL)) {
					castDirectional = 1;
					final JPanel p1 = new JPanel();
					p1.add(new JLabel("choose a direction"));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				} else if (a.getCastArea().equals(AreaOfEffect.SINGLETARGET)) {

					castSingleTarget = 1;
					final JPanel p1 = new JPanel();
					p1.add(new JLabel("select a target"));
					downPanel.add(p1);
					revalidate();
					repaint();
					final int[] count = new int[] { 0 };
					javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							if (++count[0] == 20) {
								((javax.swing.Timer) e.getSource()).stop();
								downPanel.remove(p1);
								revalidate();
								repaint();
								requestFocusInWindow();
							}

						}
					});
					t.start();

				}
			}
		}
		for (int i = 0; i < p1champions.length; i++) {
			if (e.getSource() == p1champions[i]) {
				String appliedEffects = "";
				String leaderp1 = "No";
				for (int j = 0; j < p1.getTeam().get(i).getAppliedEffects().size(); j++) {
					appliedEffects += p1.getTeam().get(i).getAppliedEffects().get(j).getName() + "("
							+ p1.getTeam().get(i).getAppliedEffects().get(j).getDuration() + ")";
				}
				if (p1.getTeam().get(i) == p1.getLeader()) {
					leaderp1 = "Yes";
				}
				JOptionPane.showConfirmDialog(null,
						"<html>Leader:" + leaderp1 + "<br><br>Type:" + p1.getTeam().get(i).getClass().getSimpleName()
								+ "<br><br>Max health:" + p1.getTeam().get(i).getMaxHP() + "<br><br>Current healt:"
								+ p1.getTeam().get(i).getCurrentHP() + "<br><br>Mana:" + p1.getTeam().get(i).getMana()
								+ "<br><br>Max actions points per turn:"
								+ p1.getTeam().get(i).getMaxActionPointsPerTurn() + "<br><br>Current actions point:"
								+ p1.getTeam().get(i).getCurrentActionPoints() + "<br><br>Attack range:"
								+ p1.getTeam().get(i).getAttackRange() + "<br><br>Attack damage:"
								+ p1.getTeam().get(i).getAttackDamage() + "<br><br>Speed:"
								+ p1.getTeam().get(i).getSpeed() + "<br><br>Condition:"
								+ p1.getTeam().get(i).getCondition() + "<br><br>Applied effects:" + appliedEffects,
						          p1.getTeam().get(i).getName(), JOptionPane.CLOSED_OPTION);
			}
		}
		for (int i = 0; i < p2champions.length; i++) {
			if (e.getSource() == p2champions[i]) {
				String appliedEffects = "";
				String leaderp2 = "No";
				for (int j = 0; j < p2.getTeam().get(i).getAppliedEffects().size(); j++) {
					appliedEffects += p2.getTeam().get(i).getAppliedEffects().get(j).getName() + "("
							+ p2.getTeam().get(i).getAppliedEffects().get(j).getDuration() + ")";
				}
				if (p1.getTeam().get(i) == p1.getLeader()) {
					leaderp2 = "Yes";
				}
				JOptionPane.showConfirmDialog(null,
						"<html>Leader:" + leaderp2 + "<br><br>Type:" + p2.getTeam().get(i).getClass().getSimpleName()
								+ "<br><br>Max health:" + p2.getTeam().get(i).getMaxHP() + "<br><br>Current healt:"
								+ p2.getTeam().get(i).getCurrentHP() + "<br><br>Mana:" + p2.getTeam().get(i).getMana()
								+ "<br><br>Max actions points per turn:"
								+ p2.getTeam().get(i).getMaxActionPointsPerTurn() + "<br><br>Current actions point:"
								+ p2.getTeam().get(i).getCurrentActionPoints() + "<br><br>Attack range:"
								+ p2.getTeam().get(i).getAttackRange() + "<br><br>Attack damage:"
								+ p2.getTeam().get(i).getAttackDamage() + "<br><br>Speed:"
								+ p2.getTeam().get(i).getSpeed() + "<br><br>Condition:"
								+ p2.getTeam().get(i).getCondition() + "<br><br>Applied effects:" + appliedEffects,
						          p2.getTeam().get(i).getName(), JOptionPane.CLOSED_OPTION);
			}
		}

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (castSingleTarget == 1) {
			for (int i = 0; i < 5; i++) {
				for (int j = 0; j < 5; j++) {
					if (e.getSource() == x[i][j]) {
						castSingleTarget = 0;
						try {
							game.castAbility(a, i, j);
							updateBoard();
						} catch (AbilityUseException e1) {
							final JPanel p1 = new JPanel();
							p1.add(new JLabel(e1.getMessage()));
							downPanel.add(p1);
							revalidate();
							repaint();
							final int[] count = new int[] { 0 };
							javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
								@Override
								public void actionPerformed(ActionEvent e) {
									if (++count[0] == 20) {
										((javax.swing.Timer) e.getSource()).stop();
										downPanel.remove(p1);
										revalidate();
										repaint();
										requestFocusInWindow();
									}

								}
							});
							t.start();

						} catch (NotEnoughResourcesException e1) {
							final JPanel p1 = new JPanel();
							p1.add(new JLabel(e1.getMessage()));
							downPanel.add(p1);
							revalidate();
							repaint();
							final int[] count = new int[] { 0 };
							javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
								@Override
								public void actionPerformed(ActionEvent e) {
									if (++count[0] == 20) {
										((javax.swing.Timer) e.getSource()).stop();
										downPanel.remove(p1);
										revalidate();
										repaint();
										requestFocusInWindow();
									}

								}
							});
							t.start();

						} catch (InvalidTargetException e1) {
							final JPanel p1 = new JPanel();
							p1.add(new JLabel(e1.getMessage()));
							downPanel.add(p1);
							revalidate();
							repaint();
							final int[] count = new int[] { 0 };
							javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
								@Override
								public void actionPerformed(ActionEvent e) {
									if (++count[0] == 20) {
										((javax.swing.Timer) e.getSource()).stop();
										downPanel.remove(p1);
										revalidate();
										repaint();
										requestFocusInWindow();
									}

								}
							});
							t.start();

						} catch (CloneNotSupportedException e1) {
							final JPanel p1 = new JPanel();
							p1.add(new JLabel(e1.getMessage()));
							downPanel.add(p1);
							revalidate();
							repaint();
							final int[] count = new int[] { 0 };
							javax.swing.Timer t = new javax.swing.Timer(40, new ActionListener() {
								@Override
								public void actionPerformed(ActionEvent e) {
									if (++count[0] == 20) {
										((javax.swing.Timer) e.getSource()).stop();
										downPanel.remove(p1);
										revalidate();
										repaint();
										requestFocusInWindow();
									}

								}
							});
							t.start();

						}
					}
				}
			}
		}

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		for (int i = 0; i < abilitiesb.length; i++) {
			if (e.getSource() == abilitiesb[i]) {
				Ability A = game.getCurrentChampion().getAbilities().get(i);
				String sA;
				if (A instanceof HealingAbility) {
					HealingAbility h = (HealingAbility) A;
					sA = "<html>Type:Healing ability<br>Name:" + A.getName() + "<br>Mana cost:" + A.getManaCost()
							+ "<br>Base cool down:" + A.getBaseCooldown() + "<br>Current cool down:"
							+ A.getCurrentCooldown() + "<br> Cast range:" + A.getCastRange()
							+ "<br> Required action points:" + A.getRequiredActionPoints() + "<br>Heal amount:"
							+ h.getHealAmount();
				} else if (A instanceof DamagingAbility) {
					DamagingAbility d = (DamagingAbility) A;
					sA = "<html>Type:Damaging ability<br>Name:" + A.getName() + "<br>Mana cost:" + A.getManaCost()
							+ "<br>Base cool down:" + A.getBaseCooldown() + "<br>Current cool down:"
							+ A.getCurrentCooldown() + "<br> Cast range:" + A.getCastRange()
							+ "<br> Required action points:" + A.getRequiredActionPoints() + "<br>Damage amount:"
							+ d.getDamageAmount();

				} else {
					CrowdControlAbility cc = (CrowdControlAbility) A;
					Effect effect = cc.getEffect();
					sA = "<html>Type:CrowdControl ability<br>Name:" + A.getName() + "<br>Mana cost:" + A.getManaCost()
							+ "<br>Base cool down:" + A.getBaseCooldown() + "<br>Current cool down:"
							+ A.getCurrentCooldown() + "<br> Cast range:" + A.getCastRange()
							+ "<br> Required action points:" + A.getRequiredActionPoints() + "<br>Effect name:"
							+ effect.getName() + "<br>Effect type:" + effect.getType() + "<br>Effect duration:"
							+ effect.getDuration();

				}

				abilitiesPanel = new JPanel();
				abilitiesPanel.setLocation(40, 220);
				abilitiesPanel.setSize(200, 170);
				abilitiesPanel.add(new JLabel(sA));
				rightPanel.add(abilitiesPanel);
				revalidate();
				repaint();
			}
		}

	}

	@Override
	public void mouseExited(MouseEvent e) {
		for (int i = 0; i < abilitiesb.length; i++) {
			if (e.getSource() == abilitiesb[i]) {

				rightPanel.remove(abilitiesPanel);
				revalidate();
				repaint();
			}
		}
	}
}

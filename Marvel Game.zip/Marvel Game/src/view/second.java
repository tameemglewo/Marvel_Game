package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GraphicsDevice;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import engine.Player;

public class second extends JFrame implements ActionListener {
	JTextField firstname;
	JTextField secondname;
	JButton doneButton;
	JLabel firstlabel;
	ImageIcon backgourd;
	public second() {
		backgourd = new ImageIcon("w9.jpg");

		firstname = new JTextField("first player name");
		firstname.setSize(200, 50);
		firstname.setLocation(590, 300);
		firstname.setOpaque(false);
		firstname.setBorder(BorderFactory.createRaisedBevelBorder());
		firstname.setForeground(Color.WHITE);

		secondname = new JTextField("second player name");
		secondname.setSize(200, 50);
		secondname.setLocation(590, 400);
		secondname.setOpaque(false);
		secondname.setBorder(BorderFactory.createRaisedBevelBorder());
		secondname.setForeground(Color.WHITE);

		doneButton = new JButton("Done!");
		doneButton.setSize(150, 50);
		doneButton.setLocation(615, 500);
		doneButton.setOpaque(false);
		doneButton.setContentAreaFilled(false);
		doneButton.setBorder(BorderFactory.createRaisedBevelBorder());
		doneButton.setFont(new Font("MV Boli", Font.BOLD, 15));
		doneButton.setBackground(Color.white);
		doneButton.setForeground(Color.WHITE);
		doneButton.addActionListener(this);

		firstlabel = new JLabel();
		firstlabel.setSize(1400,900);
		firstlabel.setIcon(backgourd);
		firstlabel.setOpaque(true);

		this.setSize(1400,900);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(true);
		this.setLayout(null);
		this.setTitle("Marvel game");
		this.setVisible(true);
		this.add(firstname);
		this.add(secondname);
		this.add(doneButton);
		this.add(firstlabel);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == doneButton) {
			String firstName = firstname.getText();
			String secondName = secondname.getText();
			Player player1 = new Player(firstName);
			Player player2 = new Player(secondName);
			third window = new third(player1, player2);
			this.dispose();
		}

	}
}

package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.security.auth.x500.X500Principal;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import engine.Game;
import engine.Player;
import model.world.Champion;

public class third extends JFrame implements ActionListener {
	JPanel y1;
	JLabel y11;
	JPanel y2;
	JLabel y22;
	Player p1;
	Player p2;
	JButton[] x;
	JButton[] y;
	ImageIcon x1;
	ImageIcon x2;
	ImageIcon x3;
	ImageIcon x4;
	ImageIcon x5;
	ImageIcon x6;
	ImageIcon x7;
	ImageIcon x8;
	ImageIcon x9;
	ImageIcon x10;
	ImageIcon x11;
	ImageIcon x12;
	ImageIcon x13;
	ImageIcon x14;
	ImageIcon x15;

	public third(Player p1, Player p2) {
		this.p1 = p1;
		this.p2 = p2;

		x1 = new ImageIcon("capA.jpeg");
		x2 = new ImageIcon("dedpool.jpeg");
		x3 = new ImageIcon("Dr.Strange.jpeg");
		x4 = new ImageIcon("Electro.jpeg");
		x5 = new ImageIcon("Ghost Rider.jpeg");
		x6 = new ImageIcon("Hela.jpeg");
		x7 = new ImageIcon("Hulk.jpeg");
		x8 = new ImageIcon("Iceman.jpeg");
		x9 = new ImageIcon("Ironman.jpeg");
		x10 = new ImageIcon("Loki.jpeg");
		x11 = new ImageIcon("Quicksilver.jpeg");
		x12 = new ImageIcon("Spiderman.jpg");
		x13 = new ImageIcon("Thor.jpeg");
		x14 = new ImageIcon("Venom.png");
		x15 = new ImageIcon("Yellow Jacket.png");

		y11 = new JLabel("<html>"+p1.getName()+"<br>choose<br>your<br>team");
		y11.setVerticalAlignment(JLabel.CENTER);
		y11.setHorizontalAlignment(JLabel.CENTER);
		y11.setFont(new Font("MV Boli", Font.BOLD, 16));

		// buttons
		x = new JButton[15];
		for (int i = 0; i < 15; i++) {
			x[i] = new JButton();
			x[i].setSize(new Dimension(50, 50));
			x[i].setLocation(i, i);
			switch (Game.getAvailableChampions().get(i).getName()) {
			case "Captain America":
				x[i].setIcon(x1);
				break;
			case "Deadpool":
				x[i].setIcon(x2);
				break;
			case "Dr Strange":
				x[i].setIcon(x3);
				break;
			case "Electro":
				x[i].setIcon(x4);
				break;
			case "Ghost Rider":
				x[i].setIcon(x5);
				break;
			case "Hela":
				x[i].setIcon(x6);
				break;
			case "Hulk":
				x[i].setIcon(x7);
				break;
			case "Iceman":
				x[i].setIcon(x8);
				break;
			case "Ironman":
				x[i].setIcon(x9);
				break;
			case "Loki":
				x[i].setIcon(x10);
				break;
			case "Quicksilver":
				x[i].setIcon(x11);
				break;
			case "Spiderman":
				x[i].setIcon(x12);
				break;
			case "Thor":
				x[i].setIcon(x13);
				break;
			case "Venom":
				x[i].setIcon(x14);
				break;
			case "Yellow Jacket":
				x[i].setIcon(x15);
				break;
			}
			 x[i] = new JButton(Game.getAvailableChampions().get(i).getName());
			x[i].addActionListener(this);
		}

		// firstplayer panel
		y1 = new JPanel();
		y1.setSize(1400, 900);
		y1.setLayout(new GridLayout(2, 0));
		y1.setBackground(Color.BLUE);
		y1.add(y11);
		for (int i = 0; i < 15; i++) {
			y1.add(x[i]);
		}

		y22 = new JLabel("<html>"+p2.getName()+"<br>choose<br>your<br>team");
		y22.setVerticalAlignment(JLabel.CENTER);
		y22.setHorizontalAlignment(JLabel.CENTER);
		y22.setFont(new Font("MV Boli", Font.BOLD, 16));

		y = new JButton[15];
		for (int i = 0; i < 15; i++) {
			y[i] = new JButton();
			switch (Game.getAvailableChampions().get(i).getName()) {
			case "Captain America":
				y[i].setIcon(x1);
				break;
			case "Deadpool":
				y[i].setIcon(x2);
				break;
			case "Dr Strange":
				y[i].setIcon(x3);
				break;
			case "Electro":
				y[i].setIcon(x4);
				break;
			case "Ghost Rider":
				y[i].setIcon(x5);
				break;
			case "Hela":
				y[i].setIcon(x6);
				break;
			case "Hulk":
				y[i].setIcon(x7);
				break;
			case "Iceman":
				y[i].setIcon(x8);
				break;
			case "Ironman":
				y[i].setIcon(x9);
				break;
			case "Loki":
				y[i].setIcon(x10);
				break;
			case "Quicksilver":
				y[i].setIcon(x11);
				break;
			case "Spiderman":
				y[i].setIcon(x12);
				break;
			case "Thor":
				y[i].setIcon(x13);
				break;
			case "Venom":
				y[i].setIcon(x14);
				break;
			case "Yellow Jacket":
				y[i].setIcon(x15);
				break;
			}
			y[i] = new JButton(Game.getAvailableChampions().get(i).getName());
			y[i].addActionListener(this);
		}

		// second player panel
		y2 = new JPanel();
		// y2.setVisible(true);
		y2.setSize(1400, 900);
		y2.setLayout(new GridLayout(2, 0));
		y2.setBackground(Color.RED);
		y2.add(y22);
		for (int i = 0; i < 15; i++) {
			y2.add(y[i]);
		}

		this.setSize(1400, 900);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(new GridLayout(2, 0));
		this.setTitle("Marvel game");
		this.setVisible(true);
		this.add(y1);
		this.add(y2);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		for (int i = 0; i < 15; i++) {
			if (e.getSource() == x[i]) {
				if (p1.getTeam().size() < 3) {
					Champion c = Game.getAvailableChampions().get(i);
					int answer = JOptionPane.showConfirmDialog(null,
							"Type:" + c.getClass().getSimpleName() + '\n' + "Health:" + c.getMaxHP() + '\n' + "Mana:"
									+ c.getMana() + '\n' + "Max action per turn:" + c.getMaxActionPointsPerTurn() + '\n'
									+ "Attack range:" + c.getAttackRange() + '\n' + "Attack damage:"
									+ c.getAttackDamage() + '\n' + "Speed:" + c.getSpeed() + '\n' + "Ability(1):"
									+ c.getAbilities().get(0).getName() + '\n' + "Ability(2):"
									+ c.getAbilities().get(1).getName() + '\n' + "Ability(3):"
									+ c.getAbilities().get(2).getName(),
							c.getName(), JOptionPane.YES_NO_OPTION);
					if (answer == 0) {
						p1.getTeam().add(c);
						x[i].setEnabled(false);
						y[i].setEnabled(false);
					}
				}
			} else if (e.getSource() == y[i]) {
				if (p2.getTeam().size() < 3) {

					Champion c = Game.getAvailableChampions().get(i);
					int answer = JOptionPane.showConfirmDialog(null,
							"Type:" + c.getClass().getSimpleName() + '\n' + "Health:" + c.getMaxHP() + '\n' + "Mana:"
									+ c.getMana() + '\n' + "Max action per turn:" + c.getMaxActionPointsPerTurn() + '\n'
									+ "Attack range:" + c.getAttackRange() + '\n' + "Attack damage:"
									+ c.getAttackDamage() + '\n' + "Speed:" + c.getSpeed() + '\n' + "Ability(1):"
									+ c.getAbilities().get(0).getName() + '\n' + "Ability(2):"
									+ c.getAbilities().get(1).getName() + '\n' + "Ability(3):"
									+ c.getAbilities().get(2).getName(),
							c.getName(), JOptionPane.YES_NO_OPTION);
					if (answer == 0) {
						p2.getTeam().add(c);
						x[i].setEnabled(false);
						y[i].setEnabled(false);
					}

				}
			}

		}
		if (p1.getTeam().size() == 3 && p2.getTeam().size() == 3) {
			fourth window = new fourth(p1, p2);
			this.dispose();
		}

	}
}

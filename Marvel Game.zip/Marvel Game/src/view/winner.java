package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;

import engine.Player;

public class winner extends JFrame{
	JLabel win;
	public winner(Player p) {
		super();
		win =new JLabel();
		win.setText(p.getName()+" IS THE WINNER!");
		win.setForeground(Color.green);
		win.setBackground(Color.BLACK);
		win.setOpaque(true);
		win.setSize(1500, 900);
		win.setLocation(0, 0);
		win.setFont(new Font("Elephant",Font.ITALIC,40));
		
		
		this.setSize(1500, 900);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLayout(null);
		this.setTitle("Marvel game");
		this.setBackground(Color.black);
		this.setVisible(true);
		this.add(win);
	}

}

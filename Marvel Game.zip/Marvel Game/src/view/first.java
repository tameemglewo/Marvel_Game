package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class first extends JFrame implements ActionListener {
	JButton createAgame;
	JButton howToPlay;
	JButton About;
	JButton exit;
	JLabel firstlabel;
	ImageIcon backgourd;

	public first() {
		backgourd = new ImageIcon("w10.jpg");

		createAgame = new JButton("create a new game");
		createAgame.setSize(200, 50);
		createAgame.setLocation(590, 200);
		createAgame.setOpaque(false);
		createAgame.setContentAreaFilled(false);
		createAgame.setBorder(BorderFactory.createRaisedBevelBorder());
		createAgame.setFont(new Font("MV Boli", Font.BOLD, 15));
		createAgame.setBackground(Color.white);
		createAgame.setForeground(Color.WHITE);
		createAgame.addActionListener(this);

		howToPlay = new JButton("How To Play");
		howToPlay.setSize(200, 50);
		howToPlay.setLocation(590, 300);
		howToPlay.setOpaque(false);
		howToPlay.setContentAreaFilled(false);
		howToPlay.setBorder(BorderFactory.createRaisedBevelBorder());
		howToPlay.setBackground(Color.BLACK);
		howToPlay.setFont(new Font("MV Boli", Font.BOLD, 15));
		howToPlay.setBackground(Color.white);
		howToPlay.setForeground(Color.WHITE);
		howToPlay.addActionListener(this);

		About = new JButton("About");
		About.setSize(200, 50);
		About.setLocation(590, 400);
		About.setOpaque(false);
		About.setContentAreaFilled(false);
		About.setBorder(BorderFactory.createRaisedBevelBorder());
		About.setBackground(Color.BLACK);
		About.setFont(new Font("MV Boli", Font.BOLD, 15));
		About.setBackground(Color.white);
		About.setForeground(Color.WHITE);
		About.addActionListener(this);

		exit = new JButton("exit");
		exit.setSize(200, 50);
		exit.setLocation(590, 500);
		exit.setOpaque(false);
		exit.setContentAreaFilled(false);
		exit.setBorder(BorderFactory.createRaisedBevelBorder());
		exit.setBackground(Color.BLACK);
		exit.setFont(new Font("MV Boli", Font.BOLD, 15));
		exit.setBackground(Color.white);
		exit.setForeground(Color.WHITE);
		exit.addActionListener(this);

		firstlabel = new JLabel();
		firstlabel.setSize(1400, 900);
		firstlabel.setIcon(backgourd);
		firstlabel.setOpaque(true);

		this.setSize(1400, 900);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(true);
		this.setTitle("Marvel game");
		this.setLayout(null);
		this.setVisible(true);
		this.add(createAgame);
		this.add(About);
		this.add(exit);
		this.add(howToPlay);
		this.add(firstlabel);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == createAgame) {
			second window = new second();
			this.dispose();
		} else if (e.getSource() == exit) {
			this.dispose();
		} else if (e.getSource() == howToPlay) {
			JOptionPane.showConfirmDialog(null,
					"=> Arrows: move the player on the grid.\n => Q:Ends the current champion turn.\n => W - A - S - D : attack with different directions as follows:\n-W: attack upwards \n-A: attack to left \n-S: attack downwards \n -D: attack to the right \n \n => Abilities are located at the right to the grid: \n - IF the ability is single target then select the\n"
							+ "target to attack by the mouse. \n - IF the ability is directional then choose the\n"
							+ "direction from the arrows.",
					"Player Guide", JOptionPane.CLOSED_OPTION);
		} else if (e.getSource() == About) {
			JOptionPane.showConfirmDialog(null,
					"Each player will select his three champions to form his team. The champions will take turns \n based on their speed. The champion with the highest speed (from all selected champions) will \n begin acting first followed by the champion with the second highest speed and so on. When \n the turn goes to a champion, the player controlling the champion can use him to carry out any \n action as long as the champion has enough action points needed for this action and also enough \n mana in case of using any of his abilities. After that, the champion can end his turn and the \n turn will go to the next champion.\n \n The turns will keep passing over the living champions till a player is able to defeat all of the \n three champions of the opponent player. In this case, the game ends and the player with the \n living champion will be declared the winner.",
					"Game flow", JOptionPane.CLOSED_OPTION);
		}

	}
}

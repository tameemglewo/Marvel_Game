package Controller;

import java.io.IOException;

import engine.Game;
import view.first;

public class main {
	public static void main(String[] args) throws IOException {
		Game.loadAbilities("Abilities.csv");
		Game.loadChampions("Champions.csv");
		first window = new first();

	}
}

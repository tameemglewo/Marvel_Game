package model.abilities;

public enum AreaOfEffect {
	SINGLETARGET, TEAMTARGET,DIRECTIONAL,SELFTARGET,SURROUND;
}

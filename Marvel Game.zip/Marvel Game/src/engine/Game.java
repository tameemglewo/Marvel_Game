package engine;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Member;
import java.util.ArrayList;

import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;
import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.effects.Disarm;
import model.effects.Dodge;
import model.effects.Effect;
import model.effects.EffectType;
import model.effects.Embrace;
import model.effects.PowerUp;
import model.effects.Root;
import model.effects.Shield;
import model.effects.Shock;
import model.effects.Silence;
import model.effects.SpeedUp;
import model.effects.Stun;
import model.world.AntiHero;
import model.world.Champion;
import model.world.Condition;
import model.world.Cover;
import model.world.Damageable;
import model.world.Direction;
import model.world.Hero;
import model.world.Villain;

public class Game {
	private static ArrayList<Champion> availableChampions = new ArrayList<>();
	private static ArrayList<Ability> availableAbilities = new ArrayList<>();
	private Player firstPlayer;
	private Player secondPlayer;
	private Object[][] board;
	private PriorityQueue turnOrder;
	private boolean firstLeaderAbilityUsed;
	private boolean secondLeaderAbilityUsed;
	private final static int BOARDWIDTH = 5;
	private final static int BOARDHEIGHT = 5;

	public Game(Player first, Player second) {
		firstPlayer = first;
		secondPlayer = second;
		//availableChampions = new ArrayList<Champion>();
		//availableAbilities = new ArrayList<Ability>();
		board = new Object[BOARDWIDTH][BOARDHEIGHT];
		turnOrder = new PriorityQueue(6);
		placeChampions();
		placeCovers();
		prepareChampionTurns();
	}

	public static void loadAbilities(String filePath) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String line = br.readLine();
		while (line != null) {
			String[] content = line.split(",");
			Ability a = null;
			AreaOfEffect ar = null;
			switch (content[5]) {
			case "SINGLETARGET":
				ar = AreaOfEffect.SINGLETARGET;
				break;
			case "TEAMTARGET":
				ar = AreaOfEffect.TEAMTARGET;
				break;
			case "SURROUND":
				ar = AreaOfEffect.SURROUND;
				break;
			case "DIRECTIONAL":
				ar = AreaOfEffect.DIRECTIONAL;
				break;
			case "SELFTARGET":
				ar = AreaOfEffect.SELFTARGET;
				break;

			}
			Effect e = null;
			if (content[0].equals("CC")) {
				switch (content[7]) {
				case "Disarm":
					e = new Disarm(Integer.parseInt(content[8]));
					break;
				case "Dodge":
					e = new Dodge(Integer.parseInt(content[8]));
					break;
				case "Embrace":
					e = new Embrace(Integer.parseInt(content[8]));
					break;
				case "PowerUp":
					e = new PowerUp(Integer.parseInt(content[8]));
					break;
				case "Root":
					e = new Root(Integer.parseInt(content[8]));
					break;
				case "Shield":
					e = new Shield(Integer.parseInt(content[8]));
					break;
				case "Shock":
					e = new Shock(Integer.parseInt(content[8]));
					break;
				case "Silence":
					e = new Silence(Integer.parseInt(content[8]));
					break;
				case "SpeedUp":
					e = new SpeedUp(Integer.parseInt(content[8]));
					break;
				case "Stun":
					e = new Stun(Integer.parseInt(content[8]));
					break;
				}
			}
			switch (content[0]) {
			case "CC":
				a = new CrowdControlAbility(content[1], Integer.parseInt(content[2]), Integer.parseInt(content[4]),
						Integer.parseInt(content[3]), ar, Integer.parseInt(content[6]), e);
				break;
			case "DMG":
				a = new DamagingAbility(content[1], Integer.parseInt(content[2]), Integer.parseInt(content[4]),
						Integer.parseInt(content[3]), ar, Integer.parseInt(content[6]), Integer.parseInt(content[7]));
				break;
			case "HEL":
				a = new HealingAbility(content[1], Integer.parseInt(content[2]), Integer.parseInt(content[4]),
						Integer.parseInt(content[3]), ar, Integer.parseInt(content[6]), Integer.parseInt(content[7]));
				break;
			}
			availableAbilities.add(a);
			line = br.readLine();
		}
		br.close();
	}

	public static void loadChampions(String filePath) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String line = br.readLine();
		while (line != null) {
			String[] content = line.split(",");
			Champion c = null;
			switch (content[0]) {
			case "A":
				c = new AntiHero(content[1], Integer.parseInt(content[2]), Integer.parseInt(content[3]),
						Integer.parseInt(content[4]), Integer.parseInt(content[5]), Integer.parseInt(content[6]),
						Integer.parseInt(content[7]));
				break;

			case "H":
				c = new Hero(content[1], Integer.parseInt(content[2]), Integer.parseInt(content[3]),
						Integer.parseInt(content[4]), Integer.parseInt(content[5]), Integer.parseInt(content[6]),
						Integer.parseInt(content[7]));
				break;
			case "V":
				c = new Villain(content[1], Integer.parseInt(content[2]), Integer.parseInt(content[3]),
						Integer.parseInt(content[4]), Integer.parseInt(content[5]), Integer.parseInt(content[6]),
						Integer.parseInt(content[7]));
				break;
			}

			c.getAbilities().add(findAbilityByName(content[8]));
			c.getAbilities().add(findAbilityByName(content[9]));
			c.getAbilities().add(findAbilityByName(content[10]));
			availableChampions.add(c);
			line = br.readLine();
		}
		br.close();
	}

	private static Ability findAbilityByName(String name) {
		for (Ability a : availableAbilities) {
			if (a.getName().equals(name))
				return a;
		}
		return null;
	}

	public void placeCovers() {
		int i = 0;
		while (i < 5) {
			int x = ((int) (Math.random() * (BOARDWIDTH - 2))) + 1;
			int y = (int) (Math.random() * BOARDHEIGHT);

			if (board[x][y] == null) {
				board[x][y] = new Cover(x, y);
				i++;
			}
		}

	}

	public void placeChampions() {
		int i = 1;
		for (Champion c : firstPlayer.getTeam()) {
			board[0][i] = c;
			c.setLocation(new Point(0, i));
			i++;
		}
		i = 1;
		for (Champion c : secondPlayer.getTeam()) {
			board[BOARDHEIGHT - 1][i] = c;
			c.setLocation(new Point(BOARDHEIGHT - 1, i));
			i++;
		}

	}

	public static ArrayList<Champion> getAvailableChampions() {
		return availableChampions;
	}

	public static ArrayList<Ability> getAvailableAbilities() {
		return availableAbilities;
	}

	public Player getFirstPlayer() {
		return firstPlayer;
	}

	public Player getSecondPlayer() {
		return secondPlayer;
	}

	public Object[][] getBoard() {
		return board;
	}

	public PriorityQueue getTurnOrder() {
		return turnOrder;
	}

	public boolean isFirstLeaderAbilityUsed() {
		return firstLeaderAbilityUsed;
	}

	public boolean isSecondLeaderAbilityUsed() {
		return secondLeaderAbilityUsed;
	}

	public static int getBoardwidth() {
		return BOARDWIDTH;
	}

	public static int getBoardheight() {
		return BOARDHEIGHT;
	}

	public Champion getCurrentChampion() {
		return (Champion) turnOrder.peekMin();

	}

	public Player checkGameOver() {
		if (firstPlayer.getTeam().isEmpty()) {
			return secondPlayer;
		} else if (secondPlayer.getTeam().isEmpty()) {
			return firstPlayer;
		} else {
			return null;
		}
	}

	public void move(Direction d) throws NotEnoughResourcesException, UnallowedMovementException {
		Champion c = getCurrentChampion();
		if (c.getCondition().equals(Condition.ACTIVE)) {
			if (c.getCurrentActionPoints() >= 1) {
				switch (d) {
				case UP:
					if (c.getLocation().x < 4) {
						int m = c.getLocation().x + 1;
						int n = c.getLocation().y;
						Point z = new Point(m, n);
						if (board[z.x][z.y] == null) {
							c.setLocation(z);
							board[z.x][z.y] = c;
							board[z.x - 1][z.y] = null;
							c.setCurrentActionPoints(c.getCurrentActionPoints() - 1);
						} else {
							throw new UnallowedMovementException("target cell is not empty");
						}

					} else {
						throw new UnallowedMovementException("Can not move out of the board");
					}
					break;

				case DOWN:
					if (c.getLocation().x > 0) {
						int m = c.getLocation().x - 1;
						int n = c.getLocation().y;
						Point z = new Point(m, n);
						if (board[z.x][z.y] == null) {
							c.setLocation(z);
							board[z.x][z.y] = c;
							board[z.x + 1][z.y] = null;
							c.setCurrentActionPoints(c.getCurrentActionPoints() - 1);
						} else {
							throw new UnallowedMovementException("target cell is not empty");
						}

					} else {
						throw new UnallowedMovementException("Can not move out of the board");
					}
					break;

				case RIGHT:
					if (c.getLocation().y < 4) {
						int m = c.getLocation().x;
						int n = c.getLocation().y + 1;
						Point z = new Point(m, n);
						if (board[z.x][z.y] == null) {
							c.setLocation(z);
							board[z.x][z.y] = c;
							board[z.x][z.y - 1] = null;
							c.setCurrentActionPoints(c.getCurrentActionPoints() - 1);
						} else {
							throw new UnallowedMovementException("target cell is not empty");
						}

					} else {
						throw new UnallowedMovementException("Can not move out of the board");
					}
					break;

				case LEFT:
					if (c.getLocation().y > 0) {
						int m = c.getLocation().x;
						int n = c.getLocation().y - 1;
						Point z = new Point(m, n);
						if (board[z.x][z.y] == null) {
							c.setLocation(z);
							board[z.x][z.y] = c;
							board[z.x][z.y + 1] = null;
							c.setCurrentActionPoints(c.getCurrentActionPoints() - 1);
						} else {
							throw new UnallowedMovementException("target cell is not empty");
						}

					} else {
						throw new UnallowedMovementException("Can not move out of the board");
					}
					break;

				}

			} else {
				throw new NotEnoughResourcesException("You need at least one action point to move");
			}
		} else {
			throw new UnallowedMovementException("You can not move while being rooted");
		}

	}

	public boolean sameTeam(Champion c, Champion attacked) {
		ArrayList<Champion> team1 = firstPlayer.getTeam();
		ArrayList<Champion> team2 = secondPlayer.getTeam();
		if ((team1.contains(c) && team2.contains(attacked)) || (team2.contains(c) && team1.contains(attacked))) {
			return false;
		}

		return true;
	}

	public void attackhelper(Champion c, Damageable d) {
		int random = 1;
		boolean shocked = false;
		if (d instanceof Cover) {
			Cover cover = (Cover) d;
			cover.setCurrentHP(cover.getCurrentHP() - c.getAttackDamage());
			if (cover.getCurrentHP() <= 0) {
				board[cover.getLocation().x][cover.getLocation().y] = null;
			}
		} else if (d instanceof Champion) {
			Champion attackedChampion = (Champion) d;
			if (!sameTeam(c, attackedChampion)) {
				boolean shieldOn = false;
				for (int s = 0; s < attackedChampion.getAppliedEffects().size(); s++) {
					if (attackedChampion.getAppliedEffects().get(s).getName().equals("Shield")) {
						Shield e = (Shield) attackedChampion.getAppliedEffects().get(s);
						e.remove(attackedChampion);
						attackedChampion.getAppliedEffects().remove(s);
						shieldOn = true;
						break;
					}
				}
				for (int a = 0; a < attackedChampion.getAppliedEffects().size(); a++) {
					if (attackedChampion.getAppliedEffects().get(a).getName().equals("Dodge")) {
						random = (int) (Math.random() * 2 +1);
						break;
					}
				}
				for (int r = 0; r < c.getAppliedEffects().size(); r++) {
					if (c.getAppliedEffects().get(r).getName().equals("Shock")) {
						shocked = true;
						break;
					}
				}
				if (shieldOn == false && random == 1 && shocked == false) {
					if (c instanceof Hero) {
						if (attackedChampion instanceof Hero) {
							attackedChampion.setCurrentHP(attackedChampion.getCurrentHP() - c.getAttackDamage());
						} else if (attackedChampion instanceof Villain) {
							attackedChampion.setCurrentHP((int) Math.ceil((attackedChampion.getCurrentHP()
									- (c.getAttackDamage() + c.getAttackDamage() / 2))));
						} else if (attackedChampion instanceof AntiHero) {
							attackedChampion.setCurrentHP((int) Math.ceil((attackedChampion.getCurrentHP()
									- (c.getAttackDamage() + c.getAttackDamage() / 2))));
						}
					} else if (c instanceof Villain) {
						if (attackedChampion instanceof Villain) {
							attackedChampion.setCurrentHP(attackedChampion.getCurrentHP() - c.getAttackDamage());
						} else if (attackedChampion instanceof Hero) {
							attackedChampion.setCurrentHP(
									(int) Math.ceil((attackedChampion.getCurrentHP() - (c.getAttackDamage() * 1.5))));
						} else if (attackedChampion instanceof AntiHero) {
							attackedChampion.setCurrentHP(
									(int) Math.ceil((attackedChampion.getCurrentHP() - (c.getAttackDamage() * 1.5))));
						}
					} else if (c instanceof AntiHero) {
						if (attackedChampion instanceof AntiHero) {
							attackedChampion.setCurrentHP(attackedChampion.getCurrentHP() - c.getAttackDamage());
						} else if (attackedChampion instanceof Hero) {
							attackedChampion.setCurrentHP(
									(int) Math.ceil((attackedChampion.getCurrentHP() - (c.getAttackDamage() * 1.5))));
						} else if (attackedChampion instanceof Villain) {
							attackedChampion.setCurrentHP(
									(int) Math.ceil((attackedChampion.getCurrentHP() - (c.getAttackDamage() * 1.5))));
						}
					}
				} else if (shieldOn == false && random == 1 && shocked == true) {
					if (c instanceof Hero) {
						if (attackedChampion instanceof Hero) {
							attackedChampion.setCurrentHP(
									(int) Math.ceil((attackedChampion.getCurrentHP() - (c.getAttackDamage() / 1.1))));
						} else {
							attackedChampion.setCurrentHP((int) Math
									.ceil((attackedChampion.getCurrentHP() - ((c.getAttackDamage() * 1.5) / 1.1))));
						}
					} else if (c instanceof Villain) {
						if (attackedChampion instanceof Villain) {
							attackedChampion.setCurrentHP(
									(int) Math.ceil((attackedChampion.getCurrentHP() - (c.getAttackDamage() / 1.1))));
						} else {
							attackedChampion.setCurrentHP((int) Math
									.ceil((attackedChampion.getCurrentHP() - ((c.getAttackDamage() * 1.5) / 1.1))));
						}
					} else if (c instanceof AntiHero) {
						if (attackedChampion instanceof AntiHero) {
							attackedChampion.setCurrentHP(
									(int) Math.ceil((attackedChampion.getCurrentHP() - (c.getAttackDamage() / 1.1))));
						} else {
							attackedChampion.setCurrentHP((int) Math
									.ceil((attackedChampion.getCurrentHP() - ((c.getAttackDamage() * 1.5) / 1.1))));
						}
					}
				}
				if (attackedChampion.getCurrentHP() <= 0) {
					attackedChampion.setCondition(Condition.KNOCKEDOUT);
					PriorityQueue alive = new PriorityQueue(6);
					while (!turnOrder.isEmpty()) {
						Champion c1 = (Champion) turnOrder.remove();
						if (c1 != attackedChampion) {
							alive.insert(c1);
						}
					}
					turnOrder = alive;
					board[attackedChampion.getLocation().x][attackedChampion.getLocation().y] = null;
					if (firstPlayer.getTeam().contains(attackedChampion)) {
						firstPlayer.getTeam().remove(attackedChampion);
					} else {
						secondPlayer.getTeam().remove(attackedChampion);
					}
				}
			}

		}
	}

	public void attack(Direction d) throws NotEnoughResourcesException, ChampionDisarmedException {
		Champion c = getCurrentChampion();
		boolean disarmed = false;
		for (int i = 0; i < c.getAppliedEffects().size(); i++) {
			if (c.getAppliedEffects().get(i).getName().equals("Disarm")) {
				disarmed = true;
				break;
			}
		}
		if (!disarmed) {
			if (c.getCurrentActionPoints() >= 2) {
				Point z = new Point();
				z = c.getLocation();
				switch (d) {
				case UP:
					for (int i = 1; i <= c.getAttackRange(); i++) {
						if (z.x + i < 5 && board[z.x + i][z.y] != null) {
							Damageable attacked = (Damageable) board[z.x + i][z.y];
							attackhelper(c, attacked);
							break;
						}
					}
					break;
				case DOWN:
					for (int i = 1; i <= c.getAttackRange(); i++) {
						if (z.x - i >= 0 && board[z.x - i][z.y] != null) {
							Damageable attacked = (Damageable) board[z.x - i][z.y];
							attackhelper(c, attacked);
							break;
						}
					}
					break;
				case RIGHT:
					for (int i = 1; i <= c.getAttackRange(); i++) {
						if (z.y + i < 5 && board[z.x][z.y + i] != null) {
							Damageable attacked = (Damageable) board[z.x][z.y + i];
							attackhelper(c, attacked);
							break;
						}
					}
					break;
				case LEFT:
					for (int i = 1; i <= c.getAttackRange(); i++) {
						if (z.y - i >= 0 && board[z.x][z.y - i] != null) {
							Damageable attacked = (Damageable) board[z.x][z.y - i];
							attackhelper(c, attacked);
							break;
						}
					}
					break;
				}
				c.setCurrentActionPoints(c.getCurrentActionPoints() - 2);
			} else {
				throw new NotEnoughResourcesException("You need at least two action point to perform a normal attack");
			}
		} else {
			throw new ChampionDisarmedException("Can not attack while being disarmed");
		}
	}

	public Player memberIn(Champion c) {

		for (int i = 0; i < firstPlayer.getTeam().size(); i++) {
			if (firstPlayer.getTeam().contains(c)) {
				return firstPlayer;
			}
		}
		return secondPlayer;
	}

	public void castAbility(Ability a) throws NotEnoughResourcesException,
			CloneNotSupportedException, AbilityUseException {
		Champion c = getCurrentChampion();
		ArrayList<Damageable> targets = new ArrayList<>();
		boolean silenced = false;
		for (int i = 0; i < c.getAppliedEffects().size(); i++) {
			if (c.getAppliedEffects().get(i).getName().equals("Silence")) {
				silenced = true;
				break;
			}
		}
		if (a.getCurrentCooldown() == 0) {
			if (silenced == false) {
				if (c.getCurrentActionPoints() >= a.getRequiredActionPoints()) {
					if (c.getMana() >= a.getManaCost()) {
						a.setCurrentCooldown(a.getBaseCooldown());
						if (a instanceof HealingAbility) {
							HealingAbility h = (HealingAbility) a;
							switch (a.getCastArea()) {
							case SELFTARGET:
								targets.add(c);
								break;
							case TEAMTARGET:
								for (int i = 0; i < memberIn(c).getTeam().size(); i++) {
									Point z = new Point();
									z = memberIn(c).getTeam().get(i).getLocation();
									int M = Math.abs(c.getLocation().x - z.x) + Math.abs(c.getLocation().y - z.y);
									if (M <= a.getCastRange()) {
										targets.add(memberIn(c).getTeam().get(i));

									}
								}
								;
								break;
							case SURROUND:
								Point z = new Point();
								z = c.getLocation();
								if (z.x + 1 < 5 && board[z.x + 1][z.y] instanceof Champion) {
									Champion c2 = (Champion) board[z.x + 1][z.y];
									if (memberIn(c).getTeam().contains(c2)) {
										targets.add(c2);
									}

								}
								if (z.y + 1 < 5 && board[z.x][z.y + 1] instanceof Champion) {
									Champion c2 = (Champion) board[z.x][z.y + 1];
									if (memberIn(c).getTeam().contains(c2)) {
										targets.add(c2);
									}

								}
								if (z.x + 1 < 5 && z.y + 1 < 5 && board[z.x + 1][z.y + 1] instanceof Champion) {
									Champion c2 = (Champion) board[z.x + 1][z.y + 1];
									if (memberIn(c).getTeam().contains(c2)) {
										targets.add(c2);
									}

								}
								if (z.x - 1 >= 0 && board[z.x - 1][z.y] instanceof Champion) {
									Champion c2 = (Champion) board[z.x - 1][z.y];
									if (memberIn(c).getTeam().contains(c2)) {
										targets.add(c2);
									}

								}
								if (z.y - 1 >= 0 && board[z.x][z.y - 1] instanceof Champion) {
									Champion c2 = (Champion) board[z.x][z.y - 1];
									if (memberIn(c).getTeam().contains(c2)) {
										targets.add(c2);
									}

								}
								if (z.y - 1 >= 0 && z.x - 1 >= 0 && board[z.x - 1][z.y - 1] instanceof Champion) {
									Champion c2 = (Champion) board[z.x - 1][z.y - 1];
									if (memberIn(c).getTeam().contains(c2)) {
										targets.add(c2);
									}

								}
								if (z.x + 1 < 5 && z.y - 1 >= 0 && board[z.x + 1][z.y - 1] instanceof Champion) {
									Champion c2 = (Champion) board[z.x + 1][z.y - 1];
									if (memberIn(c).getTeam().contains(c2)) {
										targets.add(c2);
									}

								}
								if (z.x - 1 >= 0 && z.y + 1 < 5 && board[z.x - 1][z.y + 1] instanceof Champion) {
									Champion c2 = (Champion) board[z.x - 1][z.y + 1];
									if (memberIn(c).getTeam().contains(c2)) {
										targets.add(c2);
									}

								}
							}
							h.execute(targets);

						} else if (a instanceof DamagingAbility) {
							DamagingAbility d = (DamagingAbility) a;
							switch (d.getCastArea()) {
							case TEAMTARGET:
								Player p = memberIn(c);
								if (p == firstPlayer) {
									for (int i = 0; i < secondPlayer.getTeam().size(); i++) {
										Point z = new Point();
										z = secondPlayer.getTeam().get(i).getLocation();
										int M = Math.abs(z.x - c.getLocation().x) + Math.abs(z.y - c.getLocation().y);
										if (M <= d.getCastRange()) {
											targets.add(secondPlayer.getTeam().get(i));
											for (int j = 0; j < secondPlayer.getTeam().get(i).getAppliedEffects()
													.size(); j++) {
												if (secondPlayer.getTeam().get(i).getAppliedEffects().get(j).getName()
														.equals("Shiled")) {
													targets.remove(secondPlayer.getTeam().get(i));
													secondPlayer.getTeam().get(i).getAppliedEffects().get(j)
															.remove(secondPlayer.getTeam().get(i));
													secondPlayer.getTeam().get(i).getAppliedEffects().remove(
															secondPlayer.getTeam().get(i).getAppliedEffects().get(j));
													break;
												}
											}

										}
									}
								} else {
									for (int i = 0; i < firstPlayer.getTeam().size(); i++) {
										Point z = new Point();
										z = firstPlayer.getTeam().get(i).getLocation();
										int M = Math.abs(z.x - c.getLocation().x) + Math.abs(z.y - c.getLocation().y);
										if (M <= d.getCastRange()) {
											targets.add(firstPlayer.getTeam().get(i));
											for (int j = 0; j < firstPlayer.getTeam().get(i).getAppliedEffects()
													.size(); j++) {
												if (firstPlayer.getTeam().get(i).getAppliedEffects().get(j).getName()
														.equals("Shield")) {
													targets.remove(firstPlayer.getTeam().get(i));
													firstPlayer.getTeam().get(i).getAppliedEffects().get(j)
															.remove(firstPlayer.getTeam().get(i));
													firstPlayer.getTeam().get(i).getAppliedEffects().remove(
															firstPlayer.getTeam().get(i).getAppliedEffects().get(j));
													break;
												}
											}
										}
									}
								}
								;
								break;
							case SURROUND:
								Point z = new Point();
								z = c.getLocation();
								if (z.x + 1 < 5 && board[z.x + 1][z.y] != null) {
									if (board[z.x + 1][z.y] instanceof Champion) {
										Champion c2 = (Champion) board[z.x + 1][z.y];
										if (!memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
											for (int j = 0; j < c2.getAppliedEffects().size(); j++) {
												if (c2.getAppliedEffects().get(j).getName().equals("Shield")) {
													targets.remove(c2);
													c2.getAppliedEffects().get(j).remove(c2);
													c2.getAppliedEffects().remove(c2.getAppliedEffects().get(j));
													break;
												}
											}

										}
									} else {
										targets.add((Damageable) board[z.x + 1][z.y]);
									}

								}
								if (z.y + 1 < 5 && board[z.x][z.y + 1] != null) {
									if (board[z.x][z.y + 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x][z.y + 1];
										if (!memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
											for (int j = 0; j < c2.getAppliedEffects().size(); j++) {
												if (c2.getAppliedEffects().get(j).getName().equals("Shield")) {
													targets.remove(c2);
													c2.getAppliedEffects().get(j).remove(c2);
													c2.getAppliedEffects().remove(c2.getAppliedEffects().get(j));
													break;
												}
											}
										}
									} else {
										targets.add((Damageable) board[z.x][z.y + 1]);
									}

								}
								if (z.x + 1 < 5 && z.y + 1 < 5 && board[z.x + 1][z.y + 1] != null) {
									if (board[z.x + 1][z.y + 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x + 1][z.y + 1];
										if (!memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
											for (int j = 0; j < c2.getAppliedEffects().size(); j++) {
												if (c2.getAppliedEffects().get(j).getName().equals("Shield")) {
													targets.remove(c2);
													c2.getAppliedEffects().get(j).remove(c2);
													c2.getAppliedEffects().remove(c2.getAppliedEffects().get(j));
													break;
												}
											}
										}
									} else {
										targets.add((Damageable) board[z.x + 1][z.y + 1]);
									}

								}
								if (z.x - 1 >= 0 && board[z.x - 1][z.y] != null) {
									if (board[z.x - 1][z.y] instanceof Champion) {
										Champion c2 = (Champion) board[z.x - 1][z.y];
										if (!memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
											for (int j = 0; j < c2.getAppliedEffects().size(); j++) {
												if (c2.getAppliedEffects().get(j).getName().equals("Shield")) {
													targets.remove(c2);
													c2.getAppliedEffects().get(j).remove(c2);
													c2.getAppliedEffects().remove(c2.getAppliedEffects().get(j));
													break;
												}
											}
										}
									} else {
										targets.add((Damageable) board[z.x - 1][z.y]);
									}

								}
								if (z.y - 1 >= 0 && board[z.x][z.y - 1] != null) {
									if (board[z.x][z.y - 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x][z.y - 1];
										if (!memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
											for (int j = 0; j < c2.getAppliedEffects().size(); j++) {
												if (c2.getAppliedEffects().get(j).getName().equals("Shield")) {
													targets.remove(c2);
													c2.getAppliedEffects().get(j).remove(c2);
													c2.getAppliedEffects().remove(c2.getAppliedEffects().get(j));
													break;
												}
											}
										}
									} else {
										targets.add((Damageable) board[z.x][z.y - 1]);
									}

								}
								if (z.y - 1 >= 0 && z.x - 1 >= 0 && board[z.x - 1][z.y - 1] != null) {
									if (board[z.x - 1][z.y - 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x - 1][z.y - 1];
										if (!memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
											for (int j = 0; j < c2.getAppliedEffects().size(); j++) {
												if (c2.getAppliedEffects().get(j).getName().equals("Shield")) {
													targets.remove(c2);
													c2.getAppliedEffects().get(j).remove(c2);
													c2.getAppliedEffects().remove(c2.getAppliedEffects().get(j));
													break;
												}
											}
										}
									} else {
										targets.add((Damageable) board[z.x - 1][z.y - 1]);
									}

								}
								if (z.x + 1 < 5 && z.y - 1 >= 0 && board[z.x + 1][z.y - 1] != null) {
									if (board[z.x + 1][z.y - 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x + 1][z.y - 1];
										if (!memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
											for (int j = 0; j < c2.getAppliedEffects().size(); j++) {
												if (c2.getAppliedEffects().get(j).getName().equals("Shield")) {
													targets.remove(c2);
													c2.getAppliedEffects().get(j).remove(c2);
													c2.getAppliedEffects().remove(c2.getAppliedEffects().get(j));
													break;
												}
											}
										}
									} else {
										targets.add((Damageable) board[z.x + 1][z.y - 1]);
									}

								}
								if (z.x - 1 >= 0 && z.y + 1 < 5 && board[z.x - 1][z.y + 1] != null) {
									if (board[z.x - 1][z.y + 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x - 1][z.y + 1];
										if (!memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
											for (int j = 0; j < c2.getAppliedEffects().size(); j++) {
												if (c2.getAppliedEffects().get(j).getName().equals("Shield")) {
													targets.remove(c2);
													c2.getAppliedEffects().get(j).remove(c2);
													c2.getAppliedEffects().remove(c2.getAppliedEffects().get(j));
													break;
												}
											}
										}
									} else {
										targets.add((Damageable) board[z.x - 1][z.y + 1]);
									}

								}
							}
							d.execute(targets);
							for (int i = 0; i < targets.size(); i++) {
								if (targets.get(i) instanceof Cover) {
									Cover cover = (Cover) targets.get(i);
									if (cover.getCurrentHP() <= 0) {
										board[cover.getLocation().x][cover.getLocation().y] = null;
									}
								} else {
									Champion champion = (Champion) targets.get(i);
									if (champion.getCurrentHP() <= 0) {
										champion.setCondition(Condition.KNOCKEDOUT);
										board[champion.getLocation().x][champion.getLocation().y] = null;
										if (firstPlayer.getTeam().contains(champion)) {
											firstPlayer.getTeam().remove(champion);
										} else {
											secondPlayer.getTeam().remove(champion);
										}
										PriorityQueue alive = new PriorityQueue(6);
										while (!turnOrder.isEmpty()) {
											Champion c1 = (Champion) turnOrder.remove();
											if (c1 != champion) {
												alive.insert(c1);
											}
										}
										turnOrder = alive;
									}

								}
							}

						} else if (a instanceof CrowdControlAbility) {
							CrowdControlAbility cc = (CrowdControlAbility) a;
							Effect e = cc.getEffect();
							switch (a.getCastArea()) {
							case SELFTARGET:
								if (e.getType().equals(EffectType.BUFF)) {
									targets.add(c);
								}
								;
								break;
							case TEAMTARGET:
								if (e.getType().equals(EffectType.BUFF)) {
									for (int i = 0; i < memberIn(c).getTeam().size(); i++) {
										Point z = new Point();
										z = memberIn(c).getTeam().get(i).getLocation();
										int M = Math.abs(c.getLocation().x - z.x) + Math.abs(c.getLocation().y - z.y);
										if (M <= a.getCastRange()) {
											targets.add(memberIn(c).getTeam().get(i));

										}
									}
								} else if (e.getType().equals(EffectType.DEBUFF)) {
									Player p = memberIn(c);
									if (p == firstPlayer) {
										for (int i = 0; i < secondPlayer.getTeam().size(); i++) {
											Point z = new Point();
											z = secondPlayer.getTeam().get(i).getLocation();
											int M = Math.abs(z.x - c.getLocation().x)
													+ Math.abs(z.y - c.getLocation().y);
											if (M <= a.getCastRange()) {
												targets.add(secondPlayer.getTeam().get(i));

											}
										}
									} else {
										for (int i = 0; i < firstPlayer.getTeam().size(); i++) {
											Point z = new Point();
											z = firstPlayer.getTeam().get(i).getLocation();
											int M = Math.abs(z.x - c.getLocation().x)
													+ Math.abs(z.y - c.getLocation().y);
											if (M <= a.getCastRange()) {
												targets.add(firstPlayer.getTeam().get(i));
											}
										}
									}
								}
								;
								break;
							case SURROUND:
								if (e.getType().equals(EffectType.BUFF)) {
									Point z = new Point();
									z = c.getLocation();
									if (z.x + 1 < 5 && board[z.x + 1][z.y] instanceof Champion) {
										Champion c2 = (Champion) board[z.x + 1][z.y];
										if (memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
										}

									}
									if (z.y + 1 < 5 && board[z.x][z.y + 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x][z.y + 1];
										if (memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
										}

									}
									if (z.x + 1 < 5 && z.y + 1 < 5 && board[z.x + 1][z.y + 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x + 1][z.y + 1];
										if (memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
										}

									}
									if (z.x - 1 >= 0 && board[z.x - 1][z.y] instanceof Champion) {
										Champion c2 = (Champion) board[z.x - 1][z.y];
										if (memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
										}

									}
									if (z.y - 1 >= 0 && board[z.x][z.y - 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x][z.y - 1];
										if (memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
										}

									}
									if (z.y - 1 >= 0 && z.x - 1 >= 0 && board[z.x - 1][z.y - 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x - 1][z.y - 1];
										if (memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
										}

									}
									if (z.x + 1 < 5 && z.y - 1 >= 0 && board[z.x + 1][z.y - 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x + 1][z.y - 1];
										if (memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
										}

									}
									if (z.x - 1 >= 0 && z.y + 1 < 5 && board[z.x - 1][z.y + 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x - 1][z.y + 1];
										if (memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
										}

									}
								} else if (e.getType().equals(EffectType.DEBUFF)) {
									Point z = new Point();
									z = c.getLocation();
									if (z.x + 1 < 5 && board[z.x + 1][z.y] instanceof Champion) {
										Champion c2 = (Champion) board[z.x + 1][z.y];
										if (!memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);

										}

									}
									if (z.y + 1 < 5 && board[z.x][z.y + 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x][z.y + 1];
										if (!memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);

										}

									}
									if (z.x + 1 < 5 && z.y + 1 < 5 && board[z.x + 1][z.y + 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x + 1][z.y + 1];
										if (!memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
										}

									}
									if (z.x - 1 >= 0 && board[z.x - 1][z.y] instanceof Champion) {
										Champion c2 = (Champion) board[z.x - 1][z.y];
										if (!memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
										}

									}
									if (z.y - 1 >= 0 && z.x - 1 >= 0 && board[z.x - 1][z.y - 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x - 1][z.y - 1];
										if (!memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
										}

									}
									if (z.x + 1 < 5 && z.y - 1 >= 0 && board[z.x + 1][z.y - 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x + 1][z.y - 1];
										if (!memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);

										}

									}
									if (z.x - 1 >= 0 && z.y + 1 < 5 && board[z.x - 1][z.y + 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x - 1][z.y + 1];
										if (!memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
										}

									}
									if (z.y - 1 >= 0 && board[z.x][z.y - 1] instanceof Champion) {
										Champion c2 = (Champion) board[z.x][z.y - 1];
										if (!memberIn(c).getTeam().contains(c2)) {
											targets.add(c2);
										}

									}
								}
							}
							cc.execute(targets);
							for (int i = 0; i < targets.size(); i++) {
								Champion champion = (Champion) targets.get(i);
								if (champion.getCurrentHP() <= 0) {
									board[champion.getLocation().x][champion.getLocation().y] = null;
									if (firstPlayer.getTeam().contains(champion)) {
										firstPlayer.getTeam().remove(champion);
									} else {
										secondPlayer.getTeam().remove(champion);
									}
									PriorityQueue alive = new PriorityQueue(6);
									while (!turnOrder.isEmpty()) {
										Champion c1 = (Champion) turnOrder.remove();
										if (c1 != champion) {
											alive.insert(c1);
										}
									}
									turnOrder = alive;
								}
							}
						}
						c.setCurrentActionPoints(c.getCurrentActionPoints() - a.getRequiredActionPoints());
						c.setMana(c.getMana() - a.getManaCost());

					} else {
						throw new NotEnoughResourcesException(
								"you need at least " + a.getManaCost() + " mana to cast this ability");
					}

				} else {
					throw new NotEnoughResourcesException(
							"you need at least " + a.getRequiredActionPoints() + " action points to cast this ability");
				}
			} else {
				throw new AbilityUseException("You can not cast an ability while being silenced");
			}
		} else {
			throw new AbilityUseException("You can not use an ability while it is in cooldown");
		}

	}

	public void castAbility(Ability a, Direction d)
			throws NotEnoughResourcesException, AbilityUseException, CloneNotSupportedException {
		Champion c = getCurrentChampion();
		Point z = new Point();
		z = c.getLocation();
		ArrayList<Damageable> targets = new ArrayList<>();
		boolean silenced = false;
		for (int i = 0; i < c.getAppliedEffects().size(); i++) {
			if (c.getAppliedEffects().get(i).getName().equals("Silence")) {
				silenced = true;
				break;
			}
		}
		if (silenced == false) {

			if (a.getCurrentCooldown() == 0) {
				if (c.getCurrentActionPoints() >= a.getRequiredActionPoints()) {
					if (c.getMana() >= a.getManaCost()) {

						if (a instanceof HealingAbility) {
							HealingAbility h = (HealingAbility) a;
							switch (d) {
							case UP:
								for (int i = 1; i <= a.getCastRange(); i++) {
									if (z.x + i < 5 && board[z.x + i][z.y] instanceof Champion) {
										Champion c2 = (Champion) board[z.x + i][z.y];
										if (sameTeam(c2, c)) {
											targets.add(c2);
										}

									}
								}
								break;
							case DOWN:
								for (int i = 1; i <= a.getCastRange(); i++) {
									if (z.x - i >= 0 && board[z.x - i][z.y] instanceof Champion) {
										Champion c2 = (Champion) board[z.x - i][z.y];
										if (sameTeam(c2, c)) {
											targets.add(c2);
										}

									}
								}
							case RIGHT:
								for (int i = 1; i <= a.getCastRange(); i++) {
									if (z.y + i < 5 && board[z.x][z.y + i] instanceof Champion) {
										Champion c2 = (Champion) board[z.x][z.y + i];
										if (sameTeam(c2, c)) {
											targets.add(c2);
										}

									}
								}
								break;
							case LEFT:
								for (int i = 1; i <= a.getCastRange(); i++) {
									if (z.y - i >= 0 && board[z.x][z.y - i] instanceof Champion) {
										Champion c2 = (Champion) board[z.x][z.y - i];
										if (sameTeam(c2, c)) {
											targets.add(c2);
										}

									}
								}
								break;

							}
							h.execute(targets);

						} else if (a instanceof DamagingAbility) {
							DamagingAbility da = (DamagingAbility) a;
							switch (d) {
							case UP:
								for (int i = 1; i <= a.getCastRange(); i++) {
									if (z.x + i < 5 && board[z.x + i][z.y] instanceof Cover) {
										Cover cover = (Cover) board[z.x + i][z.y];
										targets.add(cover);
									} else if (z.x + i < 5 && board[z.x + i][z.y] instanceof Champion) {
										Champion c2 = (Champion) board[z.x + i][z.y];
										if (!sameTeam(c, c2)) {
											targets.add(c2);
											for (int j = 0; j < c2.getAppliedEffects().size(); j++) {
												if (c2.getAppliedEffects().get(j).getName().equals("Shield")) {
													targets.remove(c2);
													c2.getAppliedEffects().get(j).remove(c2);
													c2.getAppliedEffects().remove(c2.getAppliedEffects().get(j));
													break;
												}
											}
										}
									}
								}
								break;
							case DOWN:
								for (int i = 1; i <= a.getCastRange(); i++) {
									if (z.x - i >= 0 && board[z.x - i][z.y] instanceof Cover) {
										Cover cover = (Cover) board[z.x - i][z.y];
										targets.add(cover);
									} else if (z.x - i >= 0 && board[z.x - i][z.y] instanceof Champion) {
										Champion c2 = (Champion) board[z.x - i][z.y];
										if (!sameTeam(c, c2)) {
											targets.add(c2);
											for (int j = 0; j < c2.getAppliedEffects().size(); j++) {
												if (c2.getAppliedEffects().get(j).getName().equals("Shield")) {
													targets.remove(c2);
													c2.getAppliedEffects().get(j).remove(c2);
													c2.getAppliedEffects().remove(c2.getAppliedEffects().get(j));
													break;
												}
											}
										}
									}
								}
								break;
							case RIGHT:
								for (int i = 1; i <= a.getCastRange(); i++) {
									if (z.y + i < 5 && board[z.x][z.y + i] instanceof Cover) {
										Cover cover = (Cover) board[z.x][z.y + i];
										targets.add(cover);
									} else if (z.y + i < 5 && board[z.x][z.y + i] instanceof Champion) {
										Champion c2 = (Champion) board[z.x][z.y + i];
										if (!sameTeam(c, c2)) {
											targets.add(c2);
											for (int j = 0; j < c2.getAppliedEffects().size(); j++) {
												if (c2.getAppliedEffects().get(j).getName().equals("Shield")) {
													targets.remove(c2);
													c2.getAppliedEffects().get(j).remove(c2);
													c2.getAppliedEffects().remove(c2.getAppliedEffects().get(j));
													break;
												}
											}

										}
									}
								}
								break;
							case LEFT:
								for (int i = 1; i <= a.getCastRange(); i++) {
									if (z.y - i >= 0 && board[z.x][z.y - i] instanceof Cover) {
										Cover cover = (Cover) board[z.x][z.y - i];
										targets.add(cover);
									} else if (z.y - i >= 0 && board[z.x][z.y - i] instanceof Champion) {
										Champion c2 = (Champion) board[z.x][z.y - i];
										if (!sameTeam(c, c2)) {
											targets.add(c2);
											for (int j = 0; j < c2.getAppliedEffects().size(); j++) {
												if (c2.getAppliedEffects().get(j).getName().equals("Shield")) {
													targets.remove(c2);
													c2.getAppliedEffects().get(j).remove(c2);
													c2.getAppliedEffects().remove(c2.getAppliedEffects().get(j));
													break;
												}
											}
										}
									}
								}
								break;
							}
							da.execute(targets);
							for (int i = 0; i < targets.size(); i++) {
								if (targets.get(i) instanceof Cover) {
									Cover cover = (Cover) targets.get(i);
									if (cover.getCurrentHP() <= 0) {
										board[cover.getLocation().x][cover.getLocation().y] = null;
									}
								} else {
									Champion champion = (Champion) targets.get(i);
									if (champion.getCurrentHP() <= 0) {
										board[champion.getLocation().x][champion.getLocation().y] = null;
										if (firstPlayer.getTeam().contains(champion)) {
											firstPlayer.getTeam().remove(champion);
										} else {
											secondPlayer.getTeam().remove(champion);
										}
										PriorityQueue alive = new PriorityQueue(6);
										while (!turnOrder.isEmpty()) {
											Champion c1 = (Champion) turnOrder.remove();
											if (c1 != champion) {
												alive.insert(c1);
											}
										}
										turnOrder = alive;
									}

								}
							}

						} else if (a instanceof CrowdControlAbility) {
							CrowdControlAbility cc = (CrowdControlAbility) a;
							Effect e = cc.getEffect();
							switch (d) {
							case UP:
								for (int i = 1; i <= a.getCastRange(); i++) {
									if (z.x + i < 5 && board[z.x + i][z.y] instanceof Champion) {
										Champion c2 = (Champion) board[z.x + i][z.y];
										if (e.getType().equals(EffectType.BUFF)) {
											if (sameTeam(c2, c)) {
												targets.add(c2);
											}
										} else if (e.getType().equals(EffectType.DEBUFF)) {
											if (!sameTeam(c2, c)) {
												targets.add(c2);
											}
										}
									}
								}
								break;
							case DOWN:
								for (int i = 1; i <= a.getCastRange(); i++) {
									if (z.x - i >= 0 && board[z.x - i][z.y] instanceof Champion) {
										Champion c2 = (Champion) board[z.x - i][z.y];
										if (e.getType().equals(EffectType.BUFF)) {
											if (sameTeam(c2, c)) {
												targets.add(c2);
											}
										} else if (e.getType().equals(EffectType.DEBUFF)) {
											if (!sameTeam(c2, c)) {
												targets.add(c2);
											}
										}
									}
								}
								break;
							case RIGHT:
								for (int i = 1; i <= a.getCastRange(); i++) {
									if (z.y + i < 5 && board[z.x][z.y + i] instanceof Champion) {
										Champion c2 = (Champion) board[z.x][z.y + i];
										if (e.getType().equals(EffectType.BUFF)) {
											if (sameTeam(c2, c)) {
												targets.add(c2);
											}
										} else if (e.getType().equals(EffectType.DEBUFF)) {
											if (!sameTeam(c2, c)) {
												targets.add(c2);
											}
										}
									}
								}
								break;
							case LEFT:
								for (int i = 1; i <= a.getCastRange(); i++) {
									if (z.y - i >= 0 && board[z.x][z.y - i] instanceof Champion) {
										Champion c2 = (Champion) board[z.x][z.y - i];
										if (e.getType().equals(EffectType.BUFF)) {
											if (sameTeam(c2, c)) {
												targets.add(c2);
											}
										} else if (e.getType().equals(EffectType.DEBUFF)) {
											if (!sameTeam(c2, c)) {
												targets.add(c2);
											}
										}
									}
								}
								break;

							}
							cc.execute(targets);
							for (int i = 0; i < targets.size(); i++) {
								Champion champion = (Champion) targets.get(i);
								if (champion.getCurrentHP() <= 0) {
									board[champion.getLocation().x][champion.getLocation().y] = null;
									if (firstPlayer.getTeam().contains(champion)) {
										firstPlayer.getTeam().remove(champion);
									} else {
										secondPlayer.getTeam().remove(champion);
									}
									PriorityQueue alive = new PriorityQueue(6);
									while (!turnOrder.isEmpty()) {
										Champion c1 = (Champion) turnOrder.remove();
										if (c1 != champion) {
											alive.insert(c1);
										}
									}
									turnOrder = alive;
								}
							}
						}
						c.setCurrentActionPoints(c.getCurrentActionPoints() - a.getRequiredActionPoints());
						c.setMana(c.getMana() - a.getManaCost());
						a.setCurrentCooldown(a.getBaseCooldown());
					} else {
						throw new NotEnoughResourcesException(
								"you need at least " + a.getManaCost() + " mana to cast this ability");
					}
				} else {
					throw new NotEnoughResourcesException(
							"you need at least " + a.getRequiredActionPoints() + " action points to cast this ability");
				}
			} else {
				throw new AbilityUseException("You can not use an ability while it is in cooldown");
			}

		} else {
			throw new AbilityUseException("You can not cast an ability while being silenced");
		}
	}

	public void castAbility(Ability a, int x, int y) throws AbilityUseException, NotEnoughResourcesException,
			InvalidTargetException, CloneNotSupportedException {
		Champion c = getCurrentChampion();
		ArrayList<Damageable> targets = new ArrayList<>();
		boolean silenced = false;
		for (int i = 0; i < c.getAppliedEffects().size(); i++) {
			if (c.getAppliedEffects().get(i).getName().equals("Silence")) {
				silenced = true;
				break;
			}
		}
		if (!silenced) {
			int M = Math.abs(c.getLocation().x - x) + Math.abs(c.getLocation().y - y);
			if (a.getCurrentCooldown() == 0) {
				if (c.getCurrentActionPoints() >= a.getRequiredActionPoints()) {
					if (c.getMana() >= a.getManaCost()) {
						if (board[x][y] != null) {
							if (M <= a.getCastRange()) {
								if (a instanceof HealingAbility) {
									HealingAbility h = (HealingAbility) a;
									if (board[x][y] instanceof Champion) {
										Champion c2 = (Champion) board[x][y];
										if (sameTeam(c2, c)) {
											targets.add(c2);
											h.execute(targets);
											c.setCurrentActionPoints(
													c.getCurrentActionPoints() - a.getRequiredActionPoints());
											c.setMana(c.getMana() - a.getManaCost());
											a.setCurrentCooldown(a.getBaseCooldown());
											
										}else {
											throw new InvalidTargetException("Can not cast healing ability on enemy targets");
										}
									} else {
										throw new InvalidTargetException("Covers can only be damaged");
									}
								} else if (a instanceof DamagingAbility) {
									DamagingAbility d = (DamagingAbility) a;
									if (board[x][y] instanceof Champion) {
										Champion c2 = (Champion) board[x][y];
										if (!sameTeam(c2, c)) {
											targets.add(c2);
											for(int i=0;i<c2.getAppliedEffects().size();i++) {
												if(c2.getAppliedEffects().get(i).getName().equals("Shield")) {
													targets.remove(c2);
													c2.getAppliedEffects().get(i).remove(c2);
													c2.getAppliedEffects().remove(c2.getAppliedEffects().get(i));
													break;
												}
											}
											d.execute(targets);
											c.setCurrentActionPoints(
													c.getCurrentActionPoints() - a.getRequiredActionPoints());
											c.setMana(c.getMana() - a.getManaCost());
											a.setCurrentCooldown(a.getBaseCooldown());
											
											if (c2.getCurrentHP() <= 0) {
												board[x][y] = null;
												if (firstPlayer.getTeam().contains(c2)) {
													firstPlayer.getTeam().remove(c2);
												} else {
													secondPlayer.getTeam().remove(c2);
												}
												PriorityQueue alive = new PriorityQueue(6);
												while (!turnOrder.isEmpty()) {
													Champion c1 = (Champion) turnOrder.remove();
													if (c1 != c2) {
														alive.insert(c1);
													}
												}
												turnOrder = alive;
											}
										} else {
											throw new InvalidTargetException("Can not cast damaging ability on friendly targets");
										}
									} else {
										Cover cover = (Cover) board[x][y];
										targets.add(cover);
										d.execute(targets);
										c.setCurrentActionPoints(
												c.getCurrentActionPoints() - a.getRequiredActionPoints());
										c.setMana(c.getMana() - a.getManaCost());
										a.setCurrentCooldown(a.getBaseCooldown());
										if (cover.getCurrentHP() <= 0) {
											board[x][y] = null;
										}
									}
								} else if (a instanceof CrowdControlAbility) {
									CrowdControlAbility cc = (CrowdControlAbility) a;
									Effect e = cc.getEffect();
									if (board[x][y] instanceof Champion) {
										Champion c2 = (Champion) board[x][y];
										if (e.getType().equals(EffectType.BUFF)) {
											if (sameTeam(c2, c)) {
												targets.add(c2);
												cc.execute(targets);
												c.setCurrentActionPoints(
														c.getCurrentActionPoints() - a.getRequiredActionPoints());
												c.setMana(c.getMana() - a.getManaCost());
												a.setCurrentCooldown(a.getBaseCooldown());

											} else {
												throw new InvalidTargetException("Can not buff enemy targets");
											}
										} else if (e.getType().equals(EffectType.DEBUFF)) {
											if (!sameTeam(c2, c)) {
												targets.add(c2);
												cc.execute(targets);
												c.setCurrentActionPoints(
														c.getCurrentActionPoints() - a.getRequiredActionPoints());
												c.setMana(c.getMana() - a.getManaCost());
												a.setCurrentCooldown(a.getBaseCooldown());

												if (c2.getCurrentHP() <= 0) {
													board[x][y] = null;
													if (firstPlayer.getTeam().contains(c2)) {
														firstPlayer.getTeam().remove(c2);
													} else {
														secondPlayer.getTeam().remove(c2);
													}
													PriorityQueue alive = new PriorityQueue(6);
													while (!turnOrder.isEmpty()) {
														Champion c1 = (Champion) turnOrder.remove();
														if (c1 != c2) {
															alive.insert(c1);
														}
													}
													turnOrder = alive;
												}

											} else {
												throw new InvalidTargetException("Can not debuff friendly targets");
											}
										}
									} else {
										throw new InvalidTargetException("Covers can only be damaged");
									}
								}

							} else {
								throw new AbilityUseException("Target out of the ability's cast range");
							}
						} else {
							throw new InvalidTargetException("You can not cast an ability on an empty cell");
						}
					} else {
						throw new NotEnoughResourcesException(
								"you need at least " + a.getManaCost() + " mana to cast this ability");
					}
				} else {
					throw new NotEnoughResourcesException(
							"you need at least " + a.getRequiredActionPoints() + " action points to cast this ability");
				}

			} else {
				throw new AbilityUseException("You can not use an ability while it is in cooldown");
			}
		} else {
			throw new AbilityUseException("You can not cast an ability while being silenced");
		}

	}

	public void useLeaderAbility() throws LeaderNotCurrentException, LeaderAbilityAlreadyUsedException {
		Champion c = getCurrentChampion();
		if (memberIn(c).getLeader().equals(c)) {
			if (memberIn(c).equals(firstPlayer)) {
				if (!firstLeaderAbilityUsed) {
					if (c instanceof Hero) {
						Hero h = (Hero) c;
						h.useLeaderAbility(firstPlayer.getTeam());
					} else if (c instanceof Villain) {
						Villain v = (Villain) c;
						v.useLeaderAbility(secondPlayer.getTeam());
						int i=0;
						while(i<secondPlayer.getTeam().size()) {
							if(secondPlayer.getTeam().get(i).getCondition().equals(Condition.KNOCKEDOUT)) {
								int x=secondPlayer.getTeam().get(i).getLocation().x;
								int y=secondPlayer.getTeam().get(i).getLocation().y;
								board[x][y]=null;
								secondPlayer.getTeam().remove(secondPlayer.getTeam().get(i));

							}else {
								i++;
							}
						}
					} else if (c instanceof AntiHero) {
						AntiHero a = (AntiHero) c;
						ArrayList<Champion> teams = new ArrayList<>();
						for (int i = 0; i < firstPlayer.getTeam().size(); i++) {
							if (!firstPlayer.getTeam().get(i).equals(firstPlayer.getLeader())) {
								teams.add(firstPlayer.getTeam().get(i));
							}
						}
						for (int i = 0; i < secondPlayer.getTeam().size(); i++) {
							if (!secondPlayer.getTeam().get(i).equals(secondPlayer.getLeader())) {
								teams.add(secondPlayer.getTeam().get(i));
							}
						}
						a.useLeaderAbility(teams);

					}
					firstLeaderAbilityUsed = true;

				} else {
					throw new LeaderAbilityAlreadyUsedException();
				}
			} else {
				if (!secondLeaderAbilityUsed) {
					if (c instanceof Hero) {
						Hero h = (Hero) c;
						h.useLeaderAbility(secondPlayer.getTeam());
					} else if (c instanceof Villain) {
						Villain v = (Villain) c;
						v.useLeaderAbility(firstPlayer.getTeam());
						int i=0;
						while(i<firstPlayer.getTeam().size()) {
							if(firstPlayer.getTeam().get(i).getCondition().equals(Condition.KNOCKEDOUT)) {
								int x=firstPlayer.getTeam().get(i).getLocation().x;
								int y=firstPlayer.getTeam().get(i).getLocation().y;
								board[x][y]=null;
								firstPlayer.getTeam().remove(firstPlayer.getTeam().get(i));

							}else {
								i++;
							}
						}
					} else if (c instanceof AntiHero) {
						AntiHero a = (AntiHero) c;
						ArrayList<Champion> teams = new ArrayList<>();
						for (int i = 0; i < firstPlayer.getTeam().size(); i++) {
							if (!firstPlayer.getTeam().get(i).equals(firstPlayer.getLeader())) {
								teams.add(firstPlayer.getTeam().get(i));
							}
						}
						for (int i = 0; i < secondPlayer.getTeam().size(); i++) {
							if (!secondPlayer.getTeam().get(i).equals(secondPlayer.getLeader())) {
								teams.add(secondPlayer.getTeam().get(i));
							}
						}
						a.useLeaderAbility(teams);
					}
					secondLeaderAbilityUsed = true;

				} else {
					throw new LeaderAbilityAlreadyUsedException();
				}
			}
		} else {
			throw new LeaderNotCurrentException();
		}
	}

	public void endTurn() {
		turnOrder.remove();
		if (!turnOrder.isEmpty()) {
			while (!turnOrder.isEmpty()) {
				Champion c = (Champion) turnOrder.peekMin();
				if (c.getCondition().equals(Condition.INACTIVE)) {
					turnOrder.remove();
				} else {
					break;
				}
			}

		}
		if (turnOrder.isEmpty()) {
			prepareChampionTurns();
		}
		

		for (int i = 0; i < firstPlayer.getTeam().size(); i++) {
			for (int j = 0; j < firstPlayer.getTeam().get(i).getAppliedEffects().size(); j++) {
				firstPlayer.getTeam().get(i).getAppliedEffects().get(j)
						.setDuration(firstPlayer.getTeam().get(i).getAppliedEffects().get(j).getDuration() - 1);
				if (firstPlayer.getTeam().get(i).getAppliedEffects().get(j).getDuration() == 0) {
					Effect e = firstPlayer.getTeam().get(i).getAppliedEffects().get(j);
					firstPlayer.getTeam().get(i).getAppliedEffects().remove(e);
					e.remove(firstPlayer.getTeam().get(i));
					
					j--;
				}
			}
			firstPlayer.getTeam().get(i)
					.setCurrentActionPoints(firstPlayer.getTeam().get(i).getMaxActionPointsPerTurn());
			for (int a = 0; a < firstPlayer.getTeam().get(i).getAbilities().size(); a++) {
				firstPlayer.getTeam().get(i).getAbilities().get(a).setCurrentCooldown(
						firstPlayer.getTeam().get(i).getAbilities().get(a).getCurrentCooldown() - 1);

			}

		}

		for (int i = 0; i < secondPlayer.getTeam().size(); i++) {
			for (int j = 0; j < secondPlayer.getTeam().get(i).getAppliedEffects().size(); j++) {
				secondPlayer.getTeam().get(i).getAppliedEffects().get(j)
						.setDuration(secondPlayer.getTeam().get(i).getAppliedEffects().get(j).getDuration() - 1);
				if (secondPlayer.getTeam().get(i).getAppliedEffects().get(j).getDuration() == 0) {
					Effect e = secondPlayer.getTeam().get(i).getAppliedEffects().get(j);
					secondPlayer.getTeam().get(i).getAppliedEffects().remove(e);
					e.remove(secondPlayer.getTeam().get(i));
					
					j--;
				}
			}
			secondPlayer.getTeam().get(i)
					.setCurrentActionPoints(secondPlayer.getTeam().get(i).getMaxActionPointsPerTurn());
			for (int a = 0; a < secondPlayer.getTeam().get(i).getAbilities().size(); a++) {
				secondPlayer.getTeam().get(i).getAbilities().get(a).setCurrentCooldown(
						secondPlayer.getTeam().get(i).getAbilities().get(a).getCurrentCooldown() - 1);
			}

		}

	}

	private void prepareChampionTurns() {
		for (int i = 0; i < firstPlayer.getTeam().size(); i++) {
			if (!firstPlayer.getTeam().get(i).getCondition().equals(Condition.INACTIVE)) {
				turnOrder.insert(firstPlayer.getTeam().get(i));
			}
		}
		for (int i = 0; i < secondPlayer.getTeam().size(); i++) {
			if (!secondPlayer.getTeam().get(i).getCondition().equals(Condition.INACTIVE)) {
				turnOrder.insert(secondPlayer.getTeam().get(i));
			}
		}

	}
}
